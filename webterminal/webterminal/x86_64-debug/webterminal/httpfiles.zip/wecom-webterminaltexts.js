
var Wecom = Wecom || {};
Wecom.webterminalTexts = {
    en: {
    },
    de: {
    }
}
