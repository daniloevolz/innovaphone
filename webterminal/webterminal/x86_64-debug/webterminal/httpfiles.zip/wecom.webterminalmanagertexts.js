
var wecom = wecom || {};
wecom.webterminalmanagertexts = {
    en: {
        pluginTitle: "webterminal",
        webterminal: "webterminal",
        webterminaladmin: "webterminal Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "webterminal",
        webterminal: "webterminal",
        webterminaladmin: "webterminal Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
