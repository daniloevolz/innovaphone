
var Wecom = Wecom || {};
Wecom.reportTexts = {
    en: {
    },
    de: {
    }
}
