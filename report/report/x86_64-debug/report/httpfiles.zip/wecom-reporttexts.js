
var Wecom = Wecom || {};
Wecom.reportTexts = {
    en: {
    },
    de: {
    },
    pt:{
        labelNameApp : "Report App",
        labelRelatórios : "Relatórios",
        labelTotalPeríodo : "Totais por Período",
        labelDetalhadoPeríodo : "Detalhado por Período",
        labelDetalhadoRamal : "Detalhado por Ramal",
        labelTotalRamal : "Total por Ramal",
        labelConfig : "Configurações"

      

    }
}
