
var Wecom = Wecom || {};
Wecom.reportTexts = {
    en: {
    },
    de: {
    },
    pt:{
        labelNameApp : "Report App",
        labelRelatórios : "Relatórios",
        labelTotalPeríodo : "Totais por Período",
        labelDetalhadoPeríodo : "Detalhado por Período",
        labelDetalhadoRamal : "Detalhado por Ramal",
        labelTotalRamal : "Total por Ramal",
        labelConfig : "Configurações",
        labelFiltros: "Filtros",
        labelDe: "DE:",
        labelAté: "ATÉ:",
        labelNumOrigem: "NÚMERO DE ORIGEM:",
        labelRamal: "RAMAL:",
        labelCancel: "Cancelar",
        labelVisualizar: "Visualizar",
        labelUsers: "Usuários",
        btnAdd: "Adicionar Usuário",
        btnDel: "Deletar Usuário",
        btnCancel: "Cancelar",
        labelAdminPanel: "Painel Admin Report",
        labelTituloUsers: "Lista de Usuários",
        cabecalho0: "Id",
        cabecalho1: "SIP",
        cabecalho2: "Nome",
        cabecalho3: "Data de Criação"

      

    }
}
