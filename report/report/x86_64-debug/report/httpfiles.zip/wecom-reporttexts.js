
var Wecom = Wecom || {};
Wecom.reportTexts = {
    en: {
    },
    de: {
    },
    pt: {
        btnPdf: "PDF",
        btnClear: "Voltar",
        labelNameApp : "Report App",
        labelRelatórios : "Relatórios",
        labelTotalPeríodo : "Totais por Período",
        labelDetalhadoPeríodo : "Detalhado por Período",
        labelDetalhadoRamal : "Detalhado por Ramal",
        labelTotalRamal: "Total por Ramal",
        labelRDisponibilidade: "Disponibilidade dos Usuários",
        labelConfig : "Configurações",
        labelFiltros: "Filtros",
        labelDe: "DE:",
        labelAté: "ATÉ:",
        labelNumOrigem: "NÚMERO DE ORIGEM:",
        labelRamal: "RAMAL:",
        labelCancel: "Cancelar",
        labelVisualizar: "Visualizar",
        labelUsersSip: "Usuários SIP:",
        labelUsersName: "Usuários Nome:",
        btnAdd: "Adicionar Usuário",
        btnDel: "Deletar Usuário",
        btnCancel: "Cancelar",
        labelAdminPanel: "Painel Admin Report",
        labelTituloUsers: "Lista de Usuários",
        cabecalho0: "Id",
        cabecalho1: "SIP",
        cabecalho2: "Nome",
        cabecalho3: "PBX",
        cabecalho4: "Data Inicio Monitoramento",
        cabecalhoDisponibilidade0: "Nome",
        cabecalhoDisponibilidade1: "Data",
        cabecalhoDisponibilidade2: "Status",
        cabecalhoDisponibilidade3:"Grupo"

      

    }
}
