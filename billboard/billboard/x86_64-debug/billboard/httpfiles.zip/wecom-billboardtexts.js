﻿
var Wecom = Wecom || {};
Wecom.billboardTexts = {
    en: {
    },
    de: {
    },
    pt: {
        labelTituloAdmin: "Bem vindo ao Quadro de Avisos",
        labelTituloLicense: "Gerenciamento de Licenças",
        labelAdmin: "Administração",
        btnOk: "Ok",
        labelCfgUsers: "Usuários",
        labelCfgLicense: "Licenças",
        lblLicenseToken: "Token do sistema:",
        labelLicenseFile: "Sua chave de licença:",
        labelLicenseActive: "Licença ativa:",
        labelAppInstallDate: "Data Expiração Lic Temp:",
        labelLicenseInstallDate: "Data instalação da Licença:",
        labelLicenseUsed: "Licenças em uso:"
    }
}
