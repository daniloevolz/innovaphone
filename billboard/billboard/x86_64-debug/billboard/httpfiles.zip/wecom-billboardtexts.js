
var Wecom = Wecom || {};
Wecom.billboardTexts = {
    en: {
    },
    de: {
    }
}
