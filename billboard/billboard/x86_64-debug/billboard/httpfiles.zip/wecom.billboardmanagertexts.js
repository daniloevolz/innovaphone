
var wecom = wecom || {};
wecom.billboardmanagertexts = {
    en: {
        pluginTitle: "billboard",
        billboard: "billboard",
        billboardadmin: "billboard Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "billboard",
        billboard: "billboard",
        billboardadmin: "billboard Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
