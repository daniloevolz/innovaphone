
var wecom = wecom || {};
wecom.testes_danilomanagertexts = {
    en: {
        pluginTitle: "TESTES_DANILO",
        testes_danilo: "TESTES_DANILO",
        testes_daniloadmin: "TESTES_DANILO Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "TESTES_DANILO",
        testes_danilo: "TESTES_DANILO",
        testes_daniloadmin: "TESTES_DANILO Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
