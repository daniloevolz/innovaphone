
var Wecom = Wecom || {};
Wecom.TESTES_DANILOTexts = {
    en: {
    },
    de: {
    }
}
