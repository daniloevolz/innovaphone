
var wecom = wecom || {};
wecom.coolworkmanagertexts = {
    en: {
        pluginTitle: "coolwork",
        coolwork: "coolwork",
        coolworkadmin: "coolwork Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "coolwork",
        coolwork: "coolwork",
        coolworkadmin: "coolwork Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
