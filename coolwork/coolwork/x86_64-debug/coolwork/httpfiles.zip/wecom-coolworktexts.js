
var Wecom = Wecom || {};
Wecom.coolworkTexts = {
    en: {
    },
    de: {
    },
    pt: {
        labelCreateRoom: "Criar Sala",
        labelRooms: "Salas",
        labelName: "Nome da Sala",
        labelGeral: "Geral",
        labelUsers: "Usuários",
        labelSchedules: "Agendamentos",
        labelSchedule : "Agendamento",
        labelDateStart : " Data de Início",
        labelDateEnd: " Data de Término",
        labelUser: "Usuário",
        labelEditor: "Editor",
        labelViewer: "Visualizador",
        labelType: "Tipo",
        labelSchedueModule: "Modelo",
        labelModuleRoom: "Modelo de Agendamento dos Telefones",
        labelTypeRoom: "Tipo de Sala",
        recurrentType: "Recorrente",
        periodType: "Período",
        periodModule: "Período do Dia",
        dayModule: "Dia Inteiro",
        hourModule: "Horário Definido",
        divStartHour: "Hora de Abertura",
        divEndHour: "Hora de Fechamento",
        labelMondayDiv: "Segunda-feira",
        labeltuesdayDiv: "Terça-feira",
        labelwednesdayDiv: "Quarta-feira",
        labelthursdayDiv: "Quinta-feira",
        labelfridayDiv: "Sexta-feira",
        labelsaturdayDiv: "Sábado",
        labelsundayDiv: "Domingo",
        labelRoomName: "Sala",
        labelScheduleDateStart: "Início do Agendamento",
        labelScheduleDateEnd: "Final do Agendamento",
        labelScheduleUser: "Usuário",
        labelDevice: "Telefone",
        labelDayWeek: "Dia da semana",
        labelScheduleModule: "Modelo de Agendamento",
        makePhoneSceduleButton: "Agendar"
        
    }
}
