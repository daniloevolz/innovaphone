
var Wecom = Wecom || {};
Wecom.coolworkTexts = {
    en: {
    },
    de: {
    },
    pt: {
        labelCreateRoom: "Criar Sala",
        labelRooms: "Salas",
        labelName: "Nome da Sala",
        labelGeral: "Geral",
        labelUsers: "Usuários",
        labelSchedule: "Agendamentos"
    }
}
