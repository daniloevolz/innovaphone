
var Wecom = Wecom || {};
Wecom.coolworkTexts = {
    en: {
    },
    de: {
    },
    pt: {
        labelCreateRoom: "Criar Sala",
        labelRooms: "Salas",
        labelName: "Nome da Sala",
    }
}
