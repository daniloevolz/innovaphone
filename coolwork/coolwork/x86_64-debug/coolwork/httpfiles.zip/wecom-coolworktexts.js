
var Wecom = Wecom || {};
Wecom.coolworkTexts = {
    en: {
    },
    de: {
    },
    pt: {
        labelCreateRoom: "Criar Sala",
        labelName: "Nome da Sala",
    }
}
