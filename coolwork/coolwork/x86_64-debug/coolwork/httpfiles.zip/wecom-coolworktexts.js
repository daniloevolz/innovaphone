
var Wecom = Wecom || {};
Wecom.coolworkTexts = {
    en: {
    },
    de: {
    }
}
