
var wecom = wecom || {};
wecom.gcalendarmanagertexts = {
    en: {
        pluginTitle: "gcalendar",
        gcalendar: "gcalendar",
        gcalendaradmin: "gcalendar Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "gcalendar",
        gcalendar: "gcalendar",
        gcalendaradmin: "gcalendar Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
