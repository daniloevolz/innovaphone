
var Wecom = Wecom || {};
Wecom.muralTexts = {
    en: {
    },
    de: {
    }
}
