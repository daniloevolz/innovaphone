﻿
var Wecom = Wecom || {};
Wecom.muralTexts = {
    en: {
        labelCfgUsers: "Users",
        labelCfgDepartments: "Sectors",
        labelCfgSkills: "Skills"
    },
    de: {
    },
    pt: {
        labelTituloAdmin: "Administração",
        labelSelectUser: "Selecione o Usuário:",
        labelDepartments: "Selecione os Departamentos",
        labelTitleUsersTable: "Tabela de Usuários",
        labelTitlePostsTable: "Tabela de Posts",
        labelAdmin:"Administração",
        labelCfgUsers: "Usuários",
        labelCfgDepartments: "Departamentos",
        labelCfgLicense: "Licensa",
        labelCfgPosts: "Posts",
        labelDepartsTitle: "Adição de Departamentos",
        labelAddDepart: "Adicionar Departamento",
        labelNameDepart: "Nome do Departamento",
        labelEditor: "Editor",
        labelViewer: "Visualizador",
        labelAdd: "Adicionar",
        btnDel: "Deletar",
        cabecalhoDepartment0: "id",
        cabecalhoDepartment1: "Departamento",
        labelTitleDepartmentsTable: "Tabela de Departamentos",
        cabecalhoUser0: "id",
        cabecalhoUser1: "Usuário",
        cabecalhoUser2: "Editor",
        cabecalhoUser3: "Visualizador",
        labelUsersTitle: "Adicionar Usuário",
        cabecalhoPosts0: "Id",
        cabecalhoPosts1: "Usuário",
        cabecalhoPosts2: "Cor",
        cabecalhoPosts3: "Título",
        cabecalhoPosts4: "Descrição",
        cabecalhoPosts5: "Departamento",
        cabecalhoPosts6: "Criação",
        cabecalhoPosts7: "Começo",
        cabecalhoPosts8: "Fim"
    }
}
