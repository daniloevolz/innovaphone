﻿
var Wecom = Wecom || {};
Wecom.muralTexts = {
    en: {
        labelCfgUsers: "Users",
        labelCfgDepartments: "Sectors",
        labelCfgSkills: "Skills"
    },
    de: {
    },
    pt: {
        labelAdmin:"Administração",
        labelCfgUsers: "Usuários",
        labelCfgDepartments: "Departamentos",
        labelCfgSkills: "Habilidades",
        labelDepartsTitle: "Adição de Departamentos",
        labelAddDepart: "Adicionar Departamento",
        labelAdd: "Adicionar",
        btnDel: "Deletar",
        cabecalho0: "id",
        cabecalho1: "Departamento",
        labelTitleDepartmentsTable: "Tabela de Departamentos",
        cabecalhoUser0: "id",
        cabecalhoUser1: "Usuário",
        cabecalhoUser2: "Editor",
        cabecalhoUser3: "Visualizador"
    }
}
