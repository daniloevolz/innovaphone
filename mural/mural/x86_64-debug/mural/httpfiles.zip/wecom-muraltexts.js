﻿
var Wecom = Wecom || {};
Wecom.muralTexts = {
    en: {
        labelCfgUsers: "Users",
        labelCfgDepartments: "Sectors",
        labelCfgSkills: "Skills"
    },
    de: {
    },
    pt: {
        labelAdmin:"Administração",
        labelCfgUsers: "Usuários",
        labelCfgDepartments: "Departamentos",
        labelCfgSkills: "Habilidades"
    }
}
