
var Wecom = Wecom || {};
Wecom.spaceTexts = {
    pt:{
        licInicio: "Início",
        licCardapio: "Cardápio",
        licCardapioUpdate: "Cardápio Atualizado todos os domingos",
    },
    en: {
    },
    de: {
    }
}
