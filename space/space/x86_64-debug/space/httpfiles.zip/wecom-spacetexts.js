
var Wecom = Wecom || {};
Wecom.spaceTexts = {
    en: {
    },
    de: {
    }
}
