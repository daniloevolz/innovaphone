
var Wecom = Wecom || {};
Wecom.monitoramentoTexts = {
    en: {
    },
    de: {
    }
}
