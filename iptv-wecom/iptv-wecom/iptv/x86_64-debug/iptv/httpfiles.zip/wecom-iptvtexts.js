
var Wecom = Wecom || {};
Wecom.iptvTexts = {
    pt:{    
        AddVideo: "Adicionar Vídeo",
        RemoveVideo: "Apagar Vídeo",
        licNome: "Nome: ",
        licTipo: "Tipo: ",
        licPagina: "Página: ",
        licURL: "URL: ",
        licUrlLogo: "URL Logo: ",
        licCancel: "Cancelar",
        licSave: "Salvar",
        labelTitle: "Painel Admin IPTV",
        AddVideo: "Adicionar Vídeo",
        RemoveVideo: "Apagar Vídeo",
        labelName: "Nome:",
        labelPage: "Página:",
        labelURL: "URL",
        labelType: "Tipo:",
        labelCancel: "Cancelar",
        labelSave: "Salvar",
        licUnLicensed: "Sistema não licenciado",
        cabecalho0: "ID",
        cabecalho1: "Nome",
        cabecalho2:"URL",
        cabecalho3: "Tipo",
        cabecalho4: "Logo",
        btnDelButton: "Apagar Vídeo",
        labelTituloAdd: "Adicionar Video",
        btnAddButton: "Adicionar Vídeo",
        btnSave: "Salvar",
        btnCancel: "Cancelar",
        iptText: " ",
        labelTituloChannels: "Lista de Canais",
        labelLogoUrl: "Logo Url",
        labelEscolherLogo: "Escolher Logo",
        labelLogos: "Logos",
        labelUnlicensed: "Sistema nao Licenciado"

    },
    en: {
    },
    de: {
    }
}
