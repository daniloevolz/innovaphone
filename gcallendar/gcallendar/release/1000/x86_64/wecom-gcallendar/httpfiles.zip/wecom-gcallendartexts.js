
var Wecom = Wecom || {};
Wecom.gcallendarTexts = {
    pt: {
        labelClientId: 'Client ID Google',
        btnUpdate: 'Atualizar',
        labelOrigins: 'URL de Redirecionamento',
        iptOrigins: 'URL',
        labelClientSecret: 'Client Secret',
        iptClientSecret: 'Client Secret',
        updated: 'Atualizado!',
        btnConnect: 'Conectar',
        btnDisconnect: 'Desconectar'
    },
    en: {
    },
    de: {
    }
}
