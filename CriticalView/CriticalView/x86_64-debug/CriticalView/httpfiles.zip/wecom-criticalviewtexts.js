
var Wecom = Wecom || {};
Wecom.CriticalViewTexts = {
    pt:{    
        AddVideo: "Adicionar Vídeo",
        RemoveVideo: "Apagar Vídeo",
        licNome: "Nome: ",
        licTipo: "Tipo: ",
        licPagina: "Página: ",
        licURL: "URL: ",
        licUrlLogo: "URL Logo: ",
        licCancel: "Cancelar",
        licSave: "Salvar"

    },
    en: {
    },
    de: {
    }
}
