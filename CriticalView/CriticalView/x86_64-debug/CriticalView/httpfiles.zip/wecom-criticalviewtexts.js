
var Wecom = Wecom || {};
Wecom.CriticalViewTexts = {
    pt:{
        labelTitle: "Painel Admin CriticalView",
        AddVideo: "Adicionar Vídeo",
        RemoveVideo: "Apagar Vídeo",
        labelName: "Nome do Video:",
        labelNamePage: "Nome da Página:",
        labelPage: "Página:",
        labelURL: "URL",
        labelType: "Tipo:",
        labelCancel: "Cancelar",
        labelSave: "Salvar",
        licUnLicensed: "Sistema não licenciado",
        cabecalho0: "ID",
        cabecalho1: "Nome",
        cabecalho2: "Nome da Página",
        cabecalho3:"Pagina",
        cabecalho4: "Tipo",
        cabecalho5: "URL",
        cabecalho6:"Logo",
        btnDelButton: "Apagar Vídeo",
        labelTituloAdd: "Adicionar Video",
        btnAddButton: "Adicionar Vídeo",
        btnSave: "Salvar",
        btnCancel: "Cancelar",
        iptText: " ",
        labelTituloChannels: "Lista de Canais",
        labelEscolherLogo: "Escolher Logo",

        

    },
    en: {
    },
    de: {
    }
}
