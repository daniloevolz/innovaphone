
var Wecom = Wecom || {};
Wecom.CriticalViewTexts = {
    en: {
    },
    de: {
    }
}
