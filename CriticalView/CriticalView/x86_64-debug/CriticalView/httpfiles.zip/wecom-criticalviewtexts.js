
var Wecom = Wecom || {};
Wecom.CriticalViewTexts = {
    pt:{
        labelTitle: "Painel Admin CriticalView",
        AddVideo: "Adicionar Vídeo",
        RemoveVideo: "Apagar Vídeo",
        labelName: "Nome:",
        labelPage: "Página:",
        labelURL: "URL",
        labelType: "Tipo:",
        labelCancel: "Cancelar",
        labelSave: "Salvar",
        licUnLicensed: "Sistema não licenciado",
        cabecalho0: "ID",
        cabecalho1: "Nome",
        cabecalho2:"Pagina",
        cabecalho3: "Tipo",
        cabecalho4: "URL",
        btnDelButton: "Apagar Vídeo",
        labelTituloAdd: "Adicionar Video",
        btnAddButton: "Adicionar Vídeo",
        btnSave: "Salvar",
        btnCancel: "Cancelar",
        iptText: " ",
        labelTituloChannels: "Lista de Canais",

        

    },
    en: {
    },
    de: {
    }
}
