
var Wecom = Wecom || {};
Wecom.CriticalViewTexts = {
    pt:{
        labelTitle: "Painel Admin CriticalView",
        AddVideo: "Adicionar Vídeo",
        RemoveVideo: "Apagar Vídeo",
        labelName: "Nome do Video:",
        labelNamePage: "Nome da Página:",
        labelPage: "Página:",
        labelURL: "URL",
        labelType: "Tipo:",
        labelCancel: "Cancelar",
        labelSave: "Salvar",
        licUnLicensed: "Sistema não licenciado",
        cabecalho0: "ID",
        cabecalho1: "Nome",
        cabecalho2: "Pagina",
        cabecalho3:"Tipo",
        cabecalho4: "URL",
        cabecalhoPage0: "ID",
        cabecalhoPage1: "Nome da Página",
        cabecalhoPage2: "Página",
        cabecalhoPage3: "Logo",
        btnDelButton: "Apagar Vídeo",
        labelTituloAdd: "Adicionar Video",
        btnAddButton: "Adicionar Vídeo",
        btnAddPage: "Criar Página",
        btnDelPage: "Deletar Página",
        btnSave: "Salvar",
        btnCancel: "Cancelar",
        iptText: " ",
        labelTituloChannels: "Lista de Canais",
        labelEscolherLogo: "Escolher Logo",
        labelTituloPage: "Lista de Páginas"

        

    },
    en: {
    },
    de: {
    }
}
