
var wecom = wecom || {};
wecom.flowemanagertexts = {
    en: {
        pluginTitle: "flowe",
        flowe: "flowe",
        floweadmin: "flowe Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "flowe",
        flowe: "flowe",
        floweadmin: "flowe Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
