
var wecom = wecom || {};
wecom.novaalertmanagertexts = {
    en: {
        pluginTitle: "novaalert",
        novaalert: "novaalert",
        novaalertadmin: "novaalert Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "novaalert",
        novaalert: "novaalert",
        novaalertadmin: "novaalert Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
