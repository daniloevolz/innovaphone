﻿
var Wecom = Wecom || {};
Wecom.novaalertTexts = {
    pt:{
        labelTituloAdmin: "Painel admin NovaAlert",
        labelNovaAlert: "Nova Alert",
        labelCheck: "Adicionar URL",
        labelURLNovaAlert: "URL NovaAlert: ",
        urlText: "URL",
        btnUpdate: "Atualizar",
        btnSave: "Salvar",
        btnCancel: "Cancelar",
        btnAlert: "Disparar Alerta!!!",
        btnAddButton: "Criar Botão",
        labelTituloAdd: "Criar Botão",
        iptText: "...",
        labelName: "Nome:",
        labelUser: "Usuário:",
        labelValue: "Valor",
        labelType: "Tipo:"

    },
    en: {
    },
    de: {
    }
}
