
var Wecom = Wecom || {};
Wecom.novaalertTexts = {
    pt:{
        labelTituloAdmin: "Painel admin NovaAlert",
        labelNovaAlert: "Nova Alert",
        labelCheck: "Adicionar URL",
        labelURLNovaAlert: "URL NovaAlert: ",
        urlText: "URL",
        btnUpdate: "Atualizar",
    },
    en: {
    },
    de: {
    }
}
