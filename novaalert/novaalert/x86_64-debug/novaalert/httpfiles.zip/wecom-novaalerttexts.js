﻿
var Wecom = Wecom || {};
Wecom.novaalertTexts = {
    pt:{
        labelTituloAdmin: "Painel admin NovaAlert",
        labelNovaAlert: "Nova Alert",
        labelCheck: "Adicionar URL",
        labelURLNovaAlert: "URL NovaAlert: ",
        urlText: "URL",
        btnUpdate: "Atualizar",
        btnSave: "Salvar",
        btnCancel: "Cancelar",
        btnAlert: "Disparar Alerta!!!",
        btnAddButton: "Criar Botão",
        labelTituloAdd: "Criar Botão",
        iptText: "...",
        labelName: "Nome:",
        labelUser: "Usuário:",
        labelValue: "Valor",
        labelType: "Tipo:",
        headerVideoPlayer: "Video Câmera",
        cabecalho0: "ID",
        cabecalho1: "Nome",
        cabecalho2:"Valor",
        cabecalho3: "Tipo",
        cabecalho4: "Usuário",
        btnDelButton: "Excluir Botões",
        labelTituloBotoes: "Lista de Botões Cadastrados",
        labelTituloAcoes: "Lista de Ações Cadastradas"
    },
    en: {
    },
    de: {
    }
}
