﻿
var Wecom = Wecom || {};
Wecom.novaalertTexts = {
    pt:{
        labelTituloAdmin: "Painel admin NovaAlert",
        labelNovaAlert: "Nova Alert",
        labelCheck: "Adicionar URL",
        labelURLNovaAlert: "URL NovaAlert: ",
        urlText: "URL",
        btnUpdate: "Atualizar",
        btnSave: "Salvar",
        btnCancel: "Cancelar",
        btnAlert: "Disparar Alerta!!!",
        btnAddButton: "Criar Botão",
        btnAddAction: "Criar Ação",
        labelTituloAdd: "Criar Botão",
        labelUserName: "Nome do Usuário SIP:",
        iptText: "...",
        labelName: "Nome:",
        labelButtonName: "Nome do Botão",
        labelUser: "Usuário:",
        labelValue: "Valor",
        labelType: "Tipo:",
        labelAlarmCode: "Código Alarme:",
        headerVideoPlayer: "Video Câmera",
        cabecalho0: "ID",
        cabecalho1: "Nome",
        cabecalho2: "Valor",
        cabecalho3: "Nome SIP",
        cabecalho4: "Tipo",
        cabecalho5: "Usuário",
        cabecalhoAction0: "ID",
        cabecalhoAction1: "Nome",
        cabecalhoAction2: "Código Alarme",
        cabecalhoAction3: "Valor",
        cabecalhoAction4: "Tipo",
        cabecalhoAction5: "Usuário",
        btnDelButton: "Excluir Botões",
        btnDelAction: "Excluir Ações",
        labelTituloBotoes: "Lista de Botões Cadastrados",
        labelTituloAcoes: "Lista de Ações Cadastradas",
        labelHistorico: "Histórico"
    },
    en: {
    },
    de: {
    }
}
