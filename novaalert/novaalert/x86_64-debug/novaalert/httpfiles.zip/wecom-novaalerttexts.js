
var Wecom = Wecom || {};
Wecom.novaalertTexts = {
    en: {
    },
    de: {
    }
}
