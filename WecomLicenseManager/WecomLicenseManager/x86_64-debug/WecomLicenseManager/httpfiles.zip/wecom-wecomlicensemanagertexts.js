﻿
var Wecom = Wecom || {};
Wecom.WecomLicenseManagerTexts = {
    pt: {
        labelTituloAdmin: "Crie chaves de licença para aplicações desenvolvidas pela Wecom para a plataforma MyApps-Innovaphone",
        labelLicenseKey: "Chave da Licença:",
        labelCfgLicense: "Licenciamento",
        labelTituloLicense: "Licenciamento do sistema",
        lblLicenseToken: "Token do Sistema:",
        labelLicenseFile: "Objeto de Licença:",
        labelLicenseInstallDate: "Data de instalação da licença:",
        btnOk: "Ok",
        erroToken: "A chave de licença precisa ser informada!",
        labelAdmin: "Aplicações"
    },
    en: {
    },
    de: {
    }
}
