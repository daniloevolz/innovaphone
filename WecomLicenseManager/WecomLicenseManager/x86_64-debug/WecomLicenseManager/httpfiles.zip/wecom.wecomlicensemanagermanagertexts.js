
var wecom = wecom || {};
wecom.wecomlicensemanagermanagertexts = {
    en: {
        pluginTitle: "WecomLicenseManager",
        wecomlicensemanager: "WecomLicenseManager",
        wecomlicensemanageradmin: "WecomLicenseManager Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add an App",
        editapp: "Edit the App",
    },
    de: {
        pluginTitle: "WecomLicenseManager",
        wecomlicensemanager: "WecomLicenseManager",
        wecomlicensemanageradmin: "WecomLicenseManager Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
    }
}
