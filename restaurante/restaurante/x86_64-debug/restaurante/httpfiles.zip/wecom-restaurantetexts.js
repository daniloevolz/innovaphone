
var Wecom = Wecom || {};
Wecom.restauranteTexts = {
    en: {
    },
    de: {
    }
}
