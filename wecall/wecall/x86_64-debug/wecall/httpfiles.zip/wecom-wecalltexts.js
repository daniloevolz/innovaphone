
var Wecom = Wecom || {};
Wecom.wecallTexts = {
    en: {
    },
    de: {
    }
}
