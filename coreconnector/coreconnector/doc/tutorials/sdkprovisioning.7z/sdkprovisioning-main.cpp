
/*---------------------------------------------------------------------------*/
/* sdkprovisioning.cpp                                                             */
/* copyright (c) innovaphone 2016                                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

#include "platform/platform.h"
#include "common/build/release.h"
#include "common/os/iomux.h"
#include "common/interface/webserver_plugin.h"
#include "common/interface/database.h"
#include "common/interface/httpfile.h"
#include "common/interface/socket.h"
#include "common/interface/json_api.h"
#include "common/lib/appservice.h"
#include "common/lib/appwebsocket.h"
#include "sdkprovisioning/sdkprovisioning.h"

int main(int argc, char *argv[])
{
    class IIoMux * iomux = IIoMux::Create();
	ISocketProvider * localSocketProvider = CreateLocalSocketProvider();
    IWebserverPluginProvider * webserverPluginProvider = CreateWebserverPluginProvider();
    IDatabaseProvider * databaseProvider = CreatePostgreSQLDatabaseProvider();

    AppServiceArgs  serviceArgs;
    serviceArgs.serviceID = "sdkprovisioning";
    serviceArgs.Parse(argc, argv);
    AppInstanceArgs instanceArgs;
    instanceArgs.appName = "sdkprovisioning";
    instanceArgs.appDomain = "example.com";
    instanceArgs.appPassword = "pwd";
    instanceArgs.webserver = "/var/run/webserver/webserver";
    instanceArgs.webserverPath = "/sdkprovisioning";
    instanceArgs.dbHost = "";
    instanceArgs.dbName = "sdkprovisioning";
    instanceArgs.dbUser = "sdkprovisioning";
    instanceArgs.dbPassword = "pwd";
    instanceArgs.Parse(argc, argv);
	
    SDKProvisioningService * service = new SDKProvisioningService(iomux, localSocketProvider, webserverPluginProvider, databaseProvider, &serviceArgs);
    if (!serviceArgs.manager) service->AppStart(&instanceArgs);
    iomux->Run();

    delete service;
	delete localSocketProvider;
    delete webserverPluginProvider;
    delete databaseProvider;
    delete iomux;
    delete debug;
    
    return 0;
}
