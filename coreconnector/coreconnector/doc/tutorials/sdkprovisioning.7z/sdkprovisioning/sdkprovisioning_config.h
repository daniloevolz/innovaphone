
class USDKProvisioningConfig : public UTask {
public:
    virtual void ConfigChanged() = 0;
    virtual void SDKProvisioningConfigClosed(class SDKProvisioningConfig * uconfig) = 0;
};

typedef std::list<class ITask *> TasksList;

/*---------------------------------------------------------------------------*/
/* SDKProvisioningConfig                                                            */
/*---------------------------------------------------------------------------*/
class SDKProvisioningConfig : public ConfigContext {
private:
    USDKProvisioningConfig * configUser;
protected:
    virtual void ConfigChanged() override;

public:
    ConfigInt        timeoutUpdate;
    ConfigString     ntp1;
    ConfigString     ntp2;
    ConfigString     timezone;
    ConfigBool       tls;
    TasksList tList;
    bool stopping;
    SDKProvisioningConfig(USDKProvisioningConfig * configUser, IDatabase * const database, IInstanceLog * const log);
    virtual ~SDKProvisioningConfig();
    virtual void Init();
    virtual void Update();
    void TryClose();
    void WriteConfigItemsComplete(class ITask * task);
    void WriteConfigItemsFailed(class ITask * task);

    class UTaskTemplate<SDKProvisioningConfig, class ITask> taskUpdateConfig;

    int TimeoutUpdate() { return this->timeoutUpdate.Value(); }
    const char * Ntp1() { return this->ntp1.Value(); }
    const char * Ntp2() { return this->ntp2.Value(); }
    const char * Timezone() { return this->timezone.Value(); }
    bool Tls() { return this->tls.Value(); }
};
