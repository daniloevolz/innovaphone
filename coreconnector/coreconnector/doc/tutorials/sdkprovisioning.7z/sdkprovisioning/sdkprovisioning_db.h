
class ProvisioningTaskDatabaseInit : public ITask, public UTask {
    class TaskPostgreSQLInitTable initRegistrations;
    class TaskPostgreSQLInitTable initConfigs;
    class TaskPostgreSQLInitTable initHistory;
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);
public:
    ProvisioningTaskDatabaseInit(IDatabase * database);
    virtual ~ProvisioningTaskDatabaseInit();
    void Start(class UTask * user);
};

class TaskWriteRegistration : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;

    void DatabaseInsertSQLResult(IDatabase * const database, ulong64 id);
    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskWriteRegistration(IDatabase * database, const char * mac, const char * code, const char * hwid, const char * username, const char * password, const char * domain, const char * dns, const char * stunserver, const char * turnserver, const char * turnusr, const char * turnpwd);
    ~TaskWriteRegistration();
    void Start(class UTask * user);
    const char * mac;
    const char * code;
    const char * hwid;
    const char * username;
    const char * password;
    const char * domain;
    const char * dns;
    const char * stunserver;
    const char * turnserver;
    const char * turnusr;
    const char * turnpwd;
};

class TaskWritePassword : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    const char * mac;
    const char * password;

    void DatabaseInsertSQLResult(IDatabase * const database, ulong64 id);
    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskWritePassword(IDatabase * database, const char * mac, const char * password);
    ~TaskWritePassword();
    void Start(class UTask * user);

};

class TaskReadPassword : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    const char * mac;

    void DatabaseInsertSQLResult(IDatabase * const database, ulong64 id);
    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskReadPassword(IDatabase * database, const char * mac);
    ~TaskReadPassword();
    void Start(class UTask * user);
    const char * password;
};

class TaskReadDevices : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    class IDataSet * dataset;

    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskReadDevices(IDatabase * database);
    ~TaskReadDevices();
    void Start(class UTask * user);
    void GetEntry(const char * & code, const char * & mac, const char * & hwid, const char * & username, bool & pwd, const char * & domain, const char * & dns, bool & provisioned, ulong64 & lastRequest, bool & devicesConfig/*, const char * & turnserver, const char * & turnusr, const char * & turnpwd, const char * & coder, const char * & tlsProfile*/);
};

class TaskWriteConfigDevice : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    const char * code;
    const char * mac;
    const char * stunserver;
    const char * turnserver;
    const char *  turnusr;
    const char * turnpwd;
    const char * coder;
    const char * tlsProfile;
    const char * ntp1;
    const char * ntp2;
    const char * timezone;
    std::list<const char *> configList;

    void DatabaseInsertSQLResult(IDatabase * const database, ulong64 id);
    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskWriteConfigDevice(IDatabase * database, const char * stunserver, const char * turnserver, const char *  turnusr, const char * turnpwd, const char * coder, const char * tlsProfile, const char * ntp1, const char * ntp2, const char * timezone, const char * code, const char * mac);
    ~TaskWriteConfigDevice();
    void Start(class UTask * user);

};

class TaskReadConfigDevice : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    bool updated;
    const char * mac;
    class IDataSet * dataset;

    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskReadConfigDevice(IDatabase * database, const char * mac);
    ~TaskReadConfigDevice();
    void Start(class UTask * user);
    void GetEntry(const char * & hwid, const char * & username, const char * & usrpwd, const char * & domain, const char * & dns, const char * & stunserver, const char * & turnserver, const char * & turnusr, const char * & turnpwd, const char * & coder, const char * & tlsProfile, const char * & ntp1, const char * & ntp2, const char * & timezone);
};

class TaskDeleteDevice : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    bool updated;
    const char * mac;
    class IDataSet * dataset;

    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskDeleteDevice(IDatabase * database, const char * mac);
    ~TaskDeleteDevice();
    void Start(class UTask * user);
};

class TaskWriteHistory : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    const char * command;
    const char * response;

    void DatabaseInsertSQLResult(IDatabase * const database, ulong64 id);
    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskWriteHistory(IDatabase * database, const char * command, bool result, const char * response);
    ~TaskWriteHistory();
    void Start(class UTask * user);
    bool result;

};

class TaskReadHistory : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    bool result;
    const char * command;
    const char * response;
    class IDataSet * dataset;

    void DatabaseInsertSQLResult(IDatabase * const database, ulong64 id);
    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskReadHistory(IDatabase * database);
    ~TaskReadHistory();
    void Start(class UTask * user);
    void GetEntry(const char * & command, bool & result, const char * & response, ulong64 & timestamp);
};

class TaskClearHistory : public ITask, public UDatabase {
    class IDatabase * database;
    class UTask * user;
    bool error;
    class IDataSet * dataset;

    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);

public:
    TaskClearHistory(IDatabase * database);
    ~TaskClearHistory();
    void Start(class UTask * user);
};
