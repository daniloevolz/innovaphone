
/*---------------------------------------------------------------------------*/
/* sdkprovisioning.cpp                                                               */
/* copyright (c) innovaphone 2016                                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

#include "platform/platform.h"
#include "common/os/iomux.h"
#include "common/interface/http_client.h"
#include "common/interface/task.h"
#include "common/interface/socket.h"
#include "common/interface/webserver_plugin.h"
#include "common/interface/services.h"
#include "common/interface/sysclient.h"
#include "common/interface/appwebsocket_client.h"
#include "common/interface/database.h"
#include "common/interface/dns.h"
#include "common/interface/json_api.h"
#include "common/interface/pbx_admin.h"
#include "common/ilib/base64.h"
#include "common/ilib/cipher.h"
#include "common/ilib/http_query_args.h"
#include "common/ilib/json.h"
#include "common/ilib/str.h"
#include "common/ilib/xml.h"
#include "common/lib/tasks_postgresql.h"
#include "common/lib/appservice.h"
#include "common/lib/appwebsocket.h"
#include "common/lib/config.h"
#include "sdkprovisioning_config.h"
#include "sdkprovisioning_db.h"
#include "sdkprovisioning.h"


class SDKProvisioningInstanceConfig : public USDKProvisioningConfig {

    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);
    void TaskProgress(class ITask * const task, dword progress);
    void ConfigChanged();
    const char * defaultServerName;
    class SDKProvisioning * sdkprovisioning;
public:
    class SDKProvisioningConfig  * config;
    bool stopping;
    SDKProvisioningInstanceConfig(SDKProvisioning * sdkprovisioning, IDatabase * const database, IInstanceLog * const log, const char * defaultServerName);
    virtual ~SDKProvisioningInstanceConfig();
    void TryClose();
    void SDKProvisioningConfigClosed(class SDKProvisioningConfig * yconfig);
};

/*---------------------------------------------------------------------------*/
/* class SDKProvisioningInstanceConfig                                              */
/*---------------------------------------------------------------------------*/
SDKProvisioningInstanceConfig::SDKProvisioningInstanceConfig(SDKProvisioning * sdkprovisioning, IDatabase * const database, IInstanceLog * const log, const char * defaultServerName)
{
    this->sdkprovisioning = sdkprovisioning;
    this->stopping = false;
    this->defaultServerName = _strdup(defaultServerName);
    this->config = new SDKProvisioningConfig(this, database, log, defaultServerName);
}

SDKProvisioningInstanceConfig::~SDKProvisioningInstanceConfig()
{
    if (defaultServerName) free((void*)defaultServerName);
    defaultServerName = NULL;
    if (this->config) delete this->config;
}

void SDKProvisioningInstanceConfig::TryClose()
{
    stopping = true;
    if (this->config) this->config->TryClose();
    else sdkprovisioning->InstanceConfigClosed(this);
}

void SDKProvisioningInstanceConfig::SDKProvisioningConfigClosed(class SDKProvisioningConfig * yconfig)
{
    delete yconfig;
    this->config = NULL;
    if (stopping) TryClose();
}

void SDKProvisioningInstanceConfig::TaskComplete(class ITask * const task)
{
    if (!sdkprovisioning->initConfig) this->sdkprovisioning->TaskCompleteConfig();
    sdkprovisioning->initConfig = true;
    delete task;
}

void SDKProvisioningInstanceConfig::TaskFailed(class ITask * const task)
{
    if (!sdkprovisioning->initConfig) this->sdkprovisioning->TaskFailedConfig();
    sdkprovisioning->initConfig = true;
    delete task;
}

void SDKProvisioningInstanceConfig::TaskProgress(class ITask * const task, dword progress)
{
    this->sdkprovisioning->TaskProgressConfig();
}

void SDKProvisioningInstanceConfig::ConfigChanged()
{
    this->sdkprovisioning->ConfigChanged();
}


/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*                                                        class SDKProvisioningService                                                         */
/*-----------------------------------------------------------------------------------------------------------------------------------*/

SDKProvisioningService::SDKProvisioningService(class IIoMux * const iomux, class ISocketProvider * localSocketProvider, class ISocketProvider * tcpSocketProvider, class ISocketProvider * tlsSocketProvider, class IWebserverPluginProvider * const webserverPluginProvider, class IDatabaseProvider * databaseProvider, AppServiceArgs * args) : AppService(iomux, localSocketProvider, args)
{
    this->iomux = iomux;
    this->localSocketProvider = localSocketProvider;
    this->tcpSocketProvider = tcpSocketProvider;
    this->tlsSocketProvider = tlsSocketProvider;
    this->webserverPluginProvider = webserverPluginProvider;
    this->databaseProvider = databaseProvider;
}

SDKProvisioningService::~SDKProvisioningService()
{

}

class AppInstance * SDKProvisioningService::CreateInstance(AppInstanceArgs * args)
{
    return new SDKProvisioning(iomux, localSocketProvider, tcpSocketProvider, tlsSocketProvider, webserverPluginProvider, databaseProvider, this, args);
}

void SDKProvisioningService::AppServiceApps(istd::list<AppServiceApp> * appList)
{
    appList->push_back(new AppServiceApp("innovaphone-sdkprovisioning"));
}

void SDKProvisioningService::AppInstancePlugins(istd::list<AppInstancePlugin> * pluginList)
{
    pluginList->push_back(new AppInstancePlugin("innovaphone.ManagerSDKProvisioning", "innovaphone-sdkprovisioning.png", "innovaphone.ManagerSDKProvisioningTexts", false));
}

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*                                                        class SDKProvisioning                                                              */
/*-----------------------------------------------------------------------------------------------------------------------------------*/

SDKProvisioning::SDKProvisioning(IIoMux * const iomux, ISocketProvider * localSocketProvider, ISocketProvider * tcpSocketProvider, ISocketProvider * tlsSocketProvider, IWebserverPluginProvider * const webserverPluginProvider, IDatabaseProvider * databaseProvider, class SDKProvisioningService * service, AppInstanceArgs * args) :
AppInstance(service, args),
taskDatabaseInit(this, &SDKProvisioning::DatabaseInitComplete, &SDKProvisioning::DatabaseInitFailed),
taskReadDevices(this, &SDKProvisioning::DatabaseReadDevicesComplete, &SDKProvisioning::DatabaseReadDevicesFailed, &SDKProvisioning::DatabaseReadDevicesProgress)
{
    this->stopping = false;
    this->initConfig = false;
    this->iomux = iomux;
    this->tcpSocketProvider = tcpSocketProvider;
    this->tlsSocketProvider = tlsSocketProvider;
    this->webserverPlugin = webserverPluginProvider->CreateWebserverPlugin(iomux, localSocketProvider, this, args->webserver, args->webserverPath, this);
    this->database = databaseProvider->CreateDatabase(iomux, this, this);
    this->database->Connect(args->dbHost, args->dbName, args->dbUser, args->dbPassword);
    this->sysclientTask = NULL;
    this->appURL = NULL;
    this->reopenSysclient = false;

    this->instanceConfig = new SDKProvisioningInstanceConfig(this, this->database, this);
    this->RegisterJsonApi(this->instanceConfig->config);
    Log("App instance started");
}

SDKProvisioning::~SDKProvisioning()
{
    if (defaultServerName) free((void*)defaultServerName);
    if (appURL) free((void*)appURL);
    defaultServerName = NULL; appURL = NULL;
    if (webserverPlugin) delete webserverPlugin;
}

void SDKProvisioning::Stop()
{
    TryStop();
}

const char * SDKProvisioning::GetAppPassword()
{
    return this->args.appPassword;
}

void SDKProvisioning::ServerCertificateUpdate(const byte * cert, size_t certLen)
{
    Log("SDKProvisioning::ServerCertificateUpdate cert:%x certLen:%u", cert, certLen);
}

void SDKProvisioning::TryStop()
{
    stopping = true;
    if (sysclientTask) return;
    if (pList.size() > 0){
        for (ProvisioningList::iterator prItr = pList.begin(); prItr != pList.end(); prItr++) {
            (*prItr)->Close(true);
        }
        return;
    }
    if (sessions.size() > 0) {
        Log("SDKProvisioning::TryStop close sessions");
        for (SDKProvisioningSessionList::iterator sessionItr = sessions.begin(); sessionItr != sessions.end(); sessionItr++) {
            (*sessionItr)->Close();
        }
        return;
    }
    if (getConfigsList.size() > 0) {
        Log("SDKProvisioning::TryStop close config requests");
        for (GetConfigsList::iterator sessionItr = getConfigsList.begin(); sessionItr != getConfigsList.end(); sessionItr++) {
            (*sessionItr)->Close();
        }
        return;
    }
    if (instanceConfig) {
        Log("SDKProvisioning::TryStop close instanceConfig");
        instanceConfig->TryClose();
        return;
    }
    if (database) {
        Log("SDKProvisioning::TryStop close database");
        database->Shutdown();
        return;
    }
    if (webserverPlugin) {
        Log("SDKProvisioning::TryStop close webserver plugin");
        webserverPlugin->Close();
        return;
    }
    appService->AppStopped(this);
}

/* Webserver plugin */

void SDKProvisioning::WebserverPluginClose(IWebserverPlugin * plugin, wsp_close_reason_t reason, bool lastUser)
{
    Log("WebserverPlugin closed");
    if (lastUser) {
        delete webserverPlugin;
        webserverPlugin = 0;
        TryStop();
    }
}

void SDKProvisioning::WebserverPluginHttpListenResult(IWebserverPlugin * plugin, ws_request_type_t requestType, char * resourceName, const char * registeredPathForRequest, size_t dataSize)
{
    Log("SDKProvisioning::WebserverHttpListenResult path=%s", resourceName);
    if (requestType == WS_REQUEST_GET) {
        //char * resource = _strdup(resourceName);
        char * ext = strrchr(resourceName, '.');
        char * mac = strrchr(resourceName, '/');
        if ((ext != NULL) && (mac != NULL) && (!strcmp(ext + 1, "boot"))) {
            mac = mac + 1;
            *ext = '\0';
            class GetConfig * req = new GetConfig(this, "boot", mac);
            getConfigsList.push_back(req);
            plugin->Accept(req);
        }
        else if ((ext != NULL) && (mac != NULL) && (!strcmp(ext + 1, "cfg"))) {
            mac = mac + 1;
            *ext = '\0';
            class GetConfig * req = new GetConfig(this, "cfg", mac);
            getConfigsList.push_back(req);
            plugin->Accept(req);
        }
        else if (plugin->BuildRedirect(resourceName, _BUILD_STRING_, strlen(_BUILD_STRING_))) {
            return;
        }
        else plugin->Cancel(WSP_CANCEL_NOT_FOUND);
    }
    /*else if (requestType == WS_REQUEST_POST) {
    }*/
    else plugin->Cancel(WSP_CANCEL_NOT_FOUND);
}

void SDKProvisioning::WebserverPluginWebsocketListenResult(IWebserverPlugin * plugin, const char * path, const char * registeredPathForRequest, const char * host)
{
    Log("SDKProvisioning::WebserverWebsocketListenResult path=%s", path);
    if (stopping) {
        plugin->Cancel(WSP_CANCEL_UNAVAILABLE);
        return;
    }
    sessions.push_back(new SDKProvisioningSession(this, plugin));
}

/* Database connection */

void SDKProvisioning::DatabaseConnectComplete(IDatabase * const database)
{
    Log("SDKProvisioning::DatabaseConnectComplete");
    this->tableSetup = new SDKProvisioningTaskDatabaseInit(database);
    this->tableSetup->Start(&taskDatabaseInit);
}

void SDKProvisioning::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    if (dataset->Eot()) {
        delete dataset;
    }
    else dataset->FetchNextRow();
}

void SDKProvisioning::DatabaseInitComplete(class TaskDatabaseInit * task)
{
    Log("SDKProvisioning::DatabaseConnectComplete");
    delete this->tableSetup;
    this->tableSetup = NULL;
    this->instanceConfig->config->Init();
}

void SDKProvisioning::DatabaseInitFailed(class TaskDatabaseInit * task)
{
    DBG_GET(("SDKProvisioning::DatabaseInitFailed"));
    delete this->tableSetup;
    this->tableSetup = NULL;
    TryStop();
}

void SDKProvisioning::DatabaseShutdown(IDatabase * const database, db_error_t reason)
{
    Log("Database closed");
    delete this->database;
    this->database = 0;
    TryStop();
}

void SDKProvisioning::DatabaseError(IDatabase * const database, db_error_t error)
{
    Log("Database Error");
    this->DatabaseShutdown(database, error);
}

/* Delete objects */

void SDKProvisioning::InstanceConfigClosed(class SDKProvisioningInstanceConfig * iconfig)
{
    Log("SDKProvisioning::InstanceConfigClosed %p", iconfig);
    delete iconfig;
    this->instanceConfig = NULL;
    if (stopping) TryStop();
}

void SDKProvisioning::SDKProvisioningSessionClosed(class SDKProvisioningSession * session)
{
    sessions.remove(session);
    delete session;
    if (stopping) TryStop();
}

void SDKProvisioning::GetConfigClosed(class GetConfig * req)
{
    getConfigsList.remove(req);
    delete req;
    if (stopping) TryStop();
}

void SDKProvisioning::ReopenSysclient()
{
    if (stopping) TryStop();
    else if (!reopenSysclient){
        class IService * service = NULL;
        for (auto pbxsession : this->pbxSessions) {
            if (pbxsession->services) {
                service = pbxsession->services->GetService("com.innovaphone.devices");
                if (service) break;
            }
        }
        if (service){
            reopenSysclient = true;
            sysclientTask = new TaskReadDevices(this->database);
            sysclientTask->Start(&taskReadDevices);
        }
    }
}

void SDKProvisioning::ProvisioningDevicesClosed(class ProvisioningDevices * provisioning)
{
    Log("SDKProvisioning(%p)::ProvisioningDevicesClosed %p", this, provisioning);
    pList.remove(provisioning);
    delete provisioning;
    if (stopping) TryStop();
}

/* Config Lib */

void SDKProvisioning::TaskCompleteConfig()
{
    Log("SDKProvisioning::TaskCompleteConfig");
    this->webserverPlugin->HttpListen(0, 0, 0, 0, _BUILD_STRING_);
    this->webserverPlugin->WebsocketListen();
}

void SDKProvisioning::TaskFailedConfig()
{
}

void SDKProvisioning::TaskProgressConfig()
{
}

void SDKProvisioning::ConfigChanged()
{
}

const char * SDKProvisioning::EncryptPassword(const char * password)
{
    //Encrypt password to be saved in the DB    
    const char * outer = "";
    char passwd[24] = { '\0' };
    byte encPassword[24] = { '\0' };
    char key[17];
    Hex2Str(key, KEY);
    Cipher c;
    c.Init(CIPHER_RC4, (byte*)key, 16, true);
    strcpy(passwd, password);
    passwd[23] = 0;
    c.Crypt((const byte*)passwd, encPassword, 24);
    char out[24 * 2 + 1];
    for (int i = 0; i < 24; i++) sprintf(&out[i * 2], "%02x", encPassword[i]);
    outer = _strdup((char*)out);
    return outer;
}

const char * SDKProvisioning::DecryptPassword(const char * data)
{
    size_t outLen = strlen(data) + 1;
    char * out = (char*)malloc(outLen);
    size_t len = strlen(data);
    byte * i = (byte *)malloc(outLen);
    len = str::to_hexmem(data, i, (dword)outLen);
    char key[17];
    Hex2Str(key, KEY);
    Cipher c;
    c.Init(CIPHER_RC4, (byte *)key, 16, true);
    c.Crypt(i, (byte*)out, (int)len);
    out[len] = '\0';
    free(i);
    return out;
}

void SDKProvisioning::Hex2Str(char out[], const char * hex)
{
    int len = strlen(hex);
    for (int i = 0; i < len / 2; i++){
        int c1 = (int)hex[2 * i] - 48;
        if (c1 > 16){
            if (c1 > 48){
                c1 = c1 - 39;
            }
            else{
                c1 = c1 - 7;
            }
        }
        int c2 = (int)hex[2 * i + 1] - 48;
        if (c2 > 16){
            if (c2 > 48){
                c2 = c2 - 39;
            }
            else{
                c2 = c2 - 7;
            }
        }
        unsigned int vc12 = c1 * 16 + c2;
        sprintf(&out[i], "%c", vc12);
    }
    out[len] = '\0';
}

void SDKProvisioning::DatabaseReadDevicesComplete(class TaskReadDevices * task)
{
    if (task == sysclientTask) sysclientTask = NULL;
    if (task) delete task;
    task = NULL;
    if (stopping) TryStop();
}

void SDKProvisioning::DatabaseReadDevicesProgress(class TaskReadDevices * task, dword progress)
{
    const char * code;
    const char * mac;
    const char * hwid;
    const char * username;
    bool pwd;
    const char * domain;
    const char * dns;
    bool provisioned;
    ulong64 lastRequest;
    bool devicesConfig;
    task->GetEntry(code, mac, hwid, username, pwd, domain, dns, provisioned, lastRequest, devicesConfig);
    class ProvisioningDevices * pd = new ProvisioningDevices(this, NULL, mac, code, true);
    this->pList.push_back(pd);
    pd->Start();
}

void SDKProvisioning::DatabaseReadDevicesFailed(class TaskReadDevices * task)
{
    if (task == sysclientTask) sysclientTask = NULL;
    if (task) delete task;
    task = NULL;
    if (stopping) TryStop();
}

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*                                                        class SDKProvisioningSession                                                       */
/*-----------------------------------------------------------------------------------------------------------------------------------*/

SDKProvisioningSession::SDKProvisioningSession(class SDKProvisioning * sdkprovisioning, class IWebserverPlugin * webserverPlugin) : AppWebsocket(webserverPlugin, sdkprovisioning, sdkprovisioning),
taskWriteRegistration(this, &SDKProvisioningSession::DatabaseWriteRegistrationComplete, &SDKProvisioningSession::DatabaseWriteRegistrationFailed),
taskReadHistory(this, &SDKProvisioningSession::DatabaseReadHistoryComplete, &SDKProvisioningSession::DatabaseReadHistoryFailed, &SDKProvisioningSession::DatabaseReadHistoryProgress),
taskReadDevices(this, &SDKProvisioningSession::DatabaseReadDevicesComplete, &SDKProvisioningSession::DatabaseReadDevicesFailed, &SDKProvisioningSession::DatabaseReadDevicesProgress),
taskClearHistory(this, &SDKProvisioningSession::DatabaseClearHistoryComplete, &SDKProvisioningSession::DatabaseClearHistoryFailed)
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::SDKProvisioningSession", this);
    this->sdkprovisioning = sdkprovisioning;
    this->closing = false;
    this->appWebsocketClosed = false;
    this->currentTask = 0;
    this->currentSrc = 0;
    this->rcv = false;
    this->url = NULL;
    this->services = NULL;
}

SDKProvisioningSession::~SDKProvisioningSession()
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::~SDKProvisioningSession", this);
    TEST_WATCH("_sdkprovisioningSession");
    if (currentSrc) free(currentSrc);
    if (this->url) free((void*)this->url);
    currentSrc = NULL; this->url = NULL;
}

void SDKProvisioningSession::AppWebsocketServiceInfo(const char * app, class json_io & msg, word base)
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::AppWebsocketServiceInfo", this);
    word apis = msg.add_object(base, "apis");
    word api = msg.add_object(apis, "com.innovaphone.provisioning");
    msg.add_string(api, "title", "SDKProvisioning");
}

char * SDKProvisioningSession::AppWebsocketPassword()
{
    return (char *)sdkprovisioning->GetAppPassword();
}

bool SDKProvisioningSession::AppWebsocketConnectComplete(class json_io & msg, word info)
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::AppWebsocketConnectComplete", this);
    if (info != JSON_ID_NONE) {
        const char * url = msg.get_string(info, "appurl");
        if (url && !sdkprovisioning->appURL) {
			/*Save the app URL if needed to redirec the phones*/
            sdkprovisioning->appURL = _strdup(url);
        }
    }
    return true;
}

void SDKProvisioningSession::AppWebsocketMessage(class json_io & msg, word base, const char * mt, const char * src)
{
    if (currentSrc) free(currentSrc);
    currentSrc = _strdup(src);
    rcv = true;
    if (!strcmp(mt, "Echo")) {
        const char * text = msg.get_string(base, "text");
        char sb[200];
        class json_io send(sb);
        word base = send.add_object(JSON_ID_ROOT, 0);
        send.add_string(base, "mt", "EchoResult");
        if (text) send.add_string(base, "text", text);
        if (src) send.add_string(base, "src", src);
        MessageComplete(send, sb);
    }
    else if (!strcmp(mt, "ProvisioningPhone")) {
        const char * mac = msg.get_string(base, "mac");
        const char * code = msg.get_string(base, "code");
        const char * hwid = msg.get_string(base, "hwid");
        const char * username = msg.get_string(base, "usename");
        const char * password = msg.get_string(base, "password");
        const char * seed1 = msg.get_string(base, "seed1");

        char * pwd = (char*)alloca(strlen(password) / 2 + 1);
        if (strlen(seed1) > 1) AppWebsocketDecrypt(seed1, password, pwd, strlen(password) / 2 + 1);

        const char * usrpwd = sdkprovisioning->EncryptPassword(pwd);
        const char * domain = msg.get_string(base, "domain");
        const char * dns = msg.get_string(base, "dns");

        currentTask = new TaskWriteRegistration(sdkprovisioning->database, mac, code, hwid, username, usrpwd, domain, dns, NULL, NULL, NULL, NULL);
        currentTask->Start(&taskWriteRegistration);

        free((void*)usrpwd);
    }
    else if (!strcmp(mt, "ReadHistory")) {
        currentTask = new TaskReadHistory(sdkprovisioning->database);
        currentTask->Start(&taskReadHistory);
    }
    else if (!strcmp(mt, "ClearHistory")) {
        currentTask = new TaskClearHistory(sdkprovisioning->database);
        currentTask->Start(&taskClearHistory);
    }
    else if (!strcmp(mt, "ReadDevices")) {
        currentTask = new TaskReadDevices(sdkprovisioning->database);
        currentTask->Start(&taskReadDevices);
    }
    else if (!strcmp(mt, "DeleteDevice")) {
        const char * mac = msg.get_string(base, "mac");
        class DeprovisioningDevices * dd = new DeprovisioningDevices(sdkprovisioning, this, mac);
        dList.push_back(dd);
        dd->Start();
    }
    else if (!strcmp(mt, "PbxInfo")) {
        if (!strcmp(app, "innovaphone-sdkprovisioning")){
            class JsonApi * jsonApi = sdkprovisioning->CreateJsonApi("PbxAdminApi", this, msg, base);
            if (jsonApi) jsonApi->JsonApiStart();
        }
        word apis = msg.get_array(base, "apis");
        if (apis != JSON_ID_NONE) {
            word last = 0;
            const char * apiName = NULL;
            while ((apiName = msg.get_string(apis, last)) != NULL) {
                if (!strcmp(apiName, "Services")) {
                    services = CreateServicesApi(this, this);
					sdkprovisioning->ReopenSysclient();
                    break;
                }
            }
        }
        sdkprovisioning->pbxSessions.push_back(this);
        if (rcv) AppWebsocketMessageComplete();
        rcv = false;
    }
    else {
        AppWebsocketMessageComplete();
        rcv = false;
    }
}

void SDKProvisioningSession::AppWebsocketClosed()
{
    this->appWebsocketClosed = true;
    TryClose();
}

void SDKProvisioningSession::TryClose()
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::TryClose", this);
    this->closing = true;
    if (currentTask) return;
    else if (pList.size() > 0) pList.front()->SessionClosed(this);
    else if (!this->appWebsocketClosed) {
        this->AppWebsocketClose();
        return;
    }
    else sdkprovisioning->SDKProvisioningSessionClosed(this);
}

void SDKProvisioningSession::Close()
{
    TryClose();
}

void SDKProvisioningSession::MessageComplete(class json_io & msg, char * buffer)
{
    AppWebsocketMessageSend(msg, buffer);
    if (rcv) AppWebsocketMessageComplete();
    rcv = false;
}

void SDKProvisioningSession::TaskFinished(class ITask * task)
{
    if (task == this->currentTask) this->currentTask = NULL;
    if (task) delete task;
    task = NULL;
    if (closing)  TryClose();
}

void SDKProvisioningSession::ServicesApiUpdated(class IServicesApi * servicesApi)
{

}
void SDKProvisioningSession::ServicesApiClosed(class IServicesApi * servicesApi)
{
    this->services = NULL;
}

void SDKProvisioningSession::DatabaseWriteRegistrationComplete(class TaskWriteRegistration * task)
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::DatabaseWriteRegistrationComplete MAC: %s Code: %s", this, task->mac, task->code);
    class ProvisioningDevices * pd = new ProvisioningDevices(sdkprovisioning, this, task->mac, task->code, false);
    sdkprovisioning->pList.push_back(pd);
    pList.push_back(pd);
    pd->Start();
    TaskFinished(task);
}

void SDKProvisioningSession::DatabaseWriteRegistrationFailed(class TaskWriteRegistration * task)
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::DatabaseWriteRegistrationFailed MAC: %s Code: %s", this, task->mac, task->code);
    char sb[800];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ProvisioningPhoneResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", "failed");
    MessageComplete(send, sb);

    TaskFinished(task);
}

void SDKProvisioningSession::ProvisioningDevicesCompleted(class ProvisioningDevices * pd, bool result, const char * error)
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::ProvisioningDevicesCompleted %p", pd);
    pList.remove(pd);
    char sb[800];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ProvisioningPhoneResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", result ? "ok" : "failed");
    if (error) send.add_string(base, "error", error);
    MessageComplete(send, sb);
    if (closing) TryClose();
}

void SDKProvisioningSession::DeprovisioningDevicesCompleted(class DeprovisioningDevices * dd, bool result, const char * error)
{
    sdkprovisioning->Log("SDKProvisioningSession(%p)::DeprovisioningDevicesCompleted", this);
    dList.remove(dd);
    delete dd;

    char sb[800];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "DeleteDeviceResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", result ? "ok" : "failed");
    if (error) send.add_string(base, "error", error);
    MessageComplete(send, sb);

    if (closing) TryClose();
}

void SDKProvisioningSession::DatabaseReadHistoryComplete(class TaskReadHistory * task)
{
    char sb[400];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ReadHistoryResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", "ok");
    MessageComplete(send, sb);
    TaskFinished(task);
}

void SDKProvisioningSession::DatabaseReadHistoryProgress(class TaskReadHistory * task, dword progress)
{
    const char * command;
    const char * response;
    bool result;
    ulong64 timestamp;
    task->GetEntry(command, result, response, timestamp);
    char b[10000];
    char * tmp = b;
    char sb[16000];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ReadHistoryInfo");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "command", command);
    send.add_bool(base, "result", result);
    send.add_string(base, "response", response);
    send.add_ulong64(base, "timestamp", timestamp, tmp);
    AppWebsocketMessageSend(send, sb);
}

void SDKProvisioningSession::DatabaseReadHistoryFailed(class TaskReadHistory * task)
{
    char sb[400];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ReadHistoryResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", "failed");
    MessageComplete(send, sb);
    TaskFinished(task);
}

void SDKProvisioningSession::DatabaseReadDevicesComplete(class TaskReadDevices * task)
{
    char sb[400];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ReadDevicesResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", "ok");
    MessageComplete(send, sb);
    TaskFinished(task);
}

void SDKProvisioningSession::DatabaseReadDevicesProgress(class TaskReadDevices * task, dword progress)
{
    const char * code;
    const char * mac;
    const char * hwid;
    const char * username;
    bool pwd;
    const char * domain;
    const char * dns;
    bool provisioned;
    ulong64 lastRequest;
    bool devicesConfig;
    task->GetEntry(code, mac, hwid, username, pwd, domain, dns, provisioned, lastRequest, devicesConfig);
    char b[10000];
    char * tmp = b;
    char sb[16000];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ReadDevicesInfo");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "code", code);
    send.add_string(base, "mac", mac);
    send.add_string(base, "hwid", hwid);
    send.add_string(base, "username", username);
    send.add_bool(base, "pwd", pwd);
    send.add_string(base, "domain", domain);
    send.add_string(base, "dns", dns);
    send.add_bool(base, "provisioned", provisioned);
    send.add_ulong64(base, "lastRequest", lastRequest, tmp);
    send.add_bool(base, "devicesConfig", devicesConfig);
    AppWebsocketMessageSend(send, sb);
}

void SDKProvisioningSession::DatabaseReadDevicesFailed(class TaskReadDevices * task)
{
    char sb[400];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ReadDevicesResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", "failed");
    MessageComplete(send, sb);
    TaskFinished(task);
}

void SDKProvisioningSession::DatabaseClearHistoryComplete(class TaskClearHistory * task)
{
    char sb[400];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ClearHistoryResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", "ok");
    MessageComplete(send, sb);
    TaskFinished(task);
}

void SDKProvisioningSession::DatabaseClearHistoryFailed(class TaskClearHistory * task)
{
    char sb[400];
    class json_io send(sb);
    word base = send.add_object(JSON_ID_ROOT, 0);
    send.add_string(base, "mt", "ClearHistoryResult");
    if (currentSrc) send.add_string(base, "src", currentSrc);
    send.add_string(base, "result", "failed");
    MessageComplete(send, sb);
    TaskFinished(task);
}

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*														class ProvisioningDevices														 */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
ProvisioningDevices::ProvisioningDevices(class SDKProvisioning * sdkprovisioning, class SDKProvisioningSession * session, const char * mac, const char * code, bool reconnect) :
taskWritePassword(this, &ProvisioningDevices::DatabaseWritePasswordComplete, &ProvisioningDevices::DatabaseWritePasswordFailed),
taskReadPassword(this, &ProvisioningDevices::DatabaseReadPasswordComplete, &ProvisioningDevices::DatabaseReadPasswordFailed),
taskWriteConfigDevice(this, &ProvisioningDevices::DatabaseWriteConfigComplete, &ProvisioningDevices::DatabaseWriteConfigFailed),
taskWriteHistory(this, &ProvisioningDevices::DatabasWriteHistoryComplete, &ProvisioningDevices::DatabaseWriteHistoryFailed)
{
    this->code = _strdup(code);
    this->mac = _strdup(mac);
    this->stopping = false;
    this->cancel = false;
    this->success = false;
    this->sdkprovisioning = sdkprovisioning;
    this->session = session;
    this->database = sdkprovisioning->database;
    this->reconnect = reconnect;
    this->historyTask = NULL;
    this->configTask = NULL;
    this->passwordTask = NULL;
    this->sysclient = NULL;
    this->password = NULL;
    this->stunserver = NULL;
    this->turnserver = NULL;
    this->turnusr = NULL;
    this->turnpwd = NULL;
    this->coder = NULL;
    this->tlsProfile = NULL;
    this->ntp1 = NULL;
    this->ntp2 = NULL;
    this->timezone = NULL;
    debug->printf("ProvisioningDevices(%p)::ProvisioningDevices session:%p", this, session);
}

ProvisioningDevices::~ProvisioningDevices()
{
    debug->printf("ProvisioningDevices(%p)::~ProvisioningDevices, session:%p", this, session);
    if (code) free((void*)code);
    if (mac) free((void*)mac);
    if (password) free((void*)password);
    if (stunserver) free((char*)stunserver);
    if (turnserver) free((char*)turnserver);
    if (turnusr) free((char*)turnusr);
    if (turnpwd) free((char*)turnpwd);
    if (coder) free((char*)coder);
    if (tlsProfile) free((char*)tlsProfile);
    if (ntp1) free((char*)ntp1);
    if (ntp2) free((char*)ntp2);
    if (timezone) free((char*)timezone);
    code = NULL; mac = NULL; password = NULL; stunserver = NULL; turnserver = NULL; turnusr = NULL; turnpwd = NULL; coder = NULL; tlsProfile = NULL; ntp1 = NULL; ntp2 = NULL; timezone = NULL;
}

void ProvisioningDevices::SessionClosed(class SDKProvisioningSession * session)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::SessionClosed %p", this, session);
    this->session->pList.remove(this);
    this->session = NULL;
    this->session->Close();
}

void ProvisioningDevices::Start()
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::Start", this);
    if (sdkprovisioning->pbxSessions.size() > 0 && sdkprovisioning->appURL){
        class IService * service = NULL;
        for (auto pbxsession : sdkprovisioning->pbxSessions) {
            if (pbxsession->services) {
                service = pbxsession->services->GetService("com.innovaphone.devices");
                if (service) break;
            }
        }
        if (service){
            const char * serviceURL = _strdup(service->GetWebsocketUrl());
            char * devicesURL = (char*)malloc(strlen(serviceURL) + 20);
            _snprintf(devicesURL, strlen(serviceURL) + 20, "%ssysclients", serviceURL);
            if (sysclient) sysclient->Close();
            sysclient = ISysclient::Create(sdkprovisioning->iomux, sdkprovisioning->tcpSocketProvider, sdkprovisioning->tlsSocketProvider, this, devicesURL, sdkprovisioning, NULL, reconnect ? NULL : code, mac);
            free((void*)devicesURL);
            free((void*)serviceURL);
        }
        else {
            sdkprovisioning->Log("ProvisioningDevices(%p) Devices Service not found!", this);
            if (session) session->ProvisioningDevicesCompleted(this, false, "Devices Service not found!");
        }
    }
    else {
        sdkprovisioning->Log("ProvisioningDevices(%p) no PBX sessions!", this);
        if (session) session->ProvisioningDevicesCompleted(this, false, "No PBX sessions!");
    }
}

void ProvisioningDevices::Stop()
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::Stop", this);
    TryClose();
}

void ProvisioningDevices::SysclientConnected(class ISysclient * sysclient)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::SysclientConnected - SendIdentify", this);
    if (!reconnect) sysclient->SendIdentify(NULL, reconnect ? NULL : code, mac, "SDKProvisioning", "1", "{ \"type\": \"PHONE\" }");
    else {
        passwordTask = new TaskReadPassword(sdkprovisioning->database, mac);
        passwordTask->Start(&taskReadPassword);
    }
}
void ProvisioningDevices::SetProvisioningCode(const char * provisioningCode)
{

}
void ProvisioningDevices::SetManagerSysClientPassword(const char * password)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::SetManagerSysClientPassword", this);
    if (this->password) free((void*)this->password);
    this->password = _strdup(password);
    if (stopping) TryClose();
    else{
        passwordTask = new TaskWritePassword(sdkprovisioning->database, mac, this->password);
        passwordTask->Start(&taskWritePassword);
    }
}
void ProvisioningDevices::SetManagerSysClient2Password(const char * password)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::SetManagerSysClient2Password", this);
}
void ProvisioningDevices::SetPasswords(const char * admin_pwd)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::SetPasswords", this);
}
void ProvisioningDevices::SetConfig(char * buffer)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::SetConfig", this);
    const char * bufferOrg = _strdup(buffer);
    class json_io json(buffer);
    if (json.decode()) {
        word base = json.get_object(JSON_ID_ROOT, NULL);
        bool last = json.get_bool(base, "last");
        word config = json.get_object(base, "config");
        if (config != JSON_ID_NONE){
            const char * type = json.get_string(config, "type");
            if (!last) last = json.get_bool(config, "last");
            if (!strcmp(type, "PHONE")) this->coder = _strdup(json.get_string(config, "coder"));
            else if (!strcmp(type, "MEDIA")){
                if (this->stunserver) free((void*)this->stunserver);
                if (this->turnserver) free((void*)this->turnserver);
                if (this->turnusr) free((void*)this->turnusr);
                if (this->turnpwd) free((void*)this->turnpwd);
                this->stunserver = _strdup(json.get_string(config, "stunServer"));
                this->turnserver = _strdup(json.get_string(config, "turnServer"));
                this->turnusr = _strdup(json.get_string(config, "turnUser"));
                const char * turnpass = json.get_string(config, "turnPassword");
                const char * seed = json.get_string(config, "turnSeed");
                dword len = strlen(turnpass) / 2 + 1;
                this->turnpwd = (char*)malloc(len);
                if (strlen(seed) > 1) this->sysclient->Decrypt(seed, turnpass, (char*)this->turnpwd, len);
            }
            else if (!strcmp(type, "TLS_PROFILE")) this->tlsProfile = _strdup(json.get_string(config, "profile"));
            else if (!strcmp(type, "NTP")){
                if (this->ntp1) free((void*)this->ntp1);
                if (this->ntp2) free((void*)this->ntp2);
                if (this->timezone) free((void*)this->timezone);
                this->timezone = NULL;
                const char * tz = _strdup(json.get_string(config, "tz"));
                this->ntp1 = _strdup(json.get_string(config, "ntp1"));
                this->ntp2 = _strdup(json.get_string(config, "ntp2"));
                if (!strcmp(tz, "GMT0BST-1,M3.5.0/1,M10.5.0/2")) timezone = _strdup("0");
                else if (!strcmp(tz, "WET0WEST-1,M3.5.0/1,M10.5.0/2")) timezone = _strdup("0");
                else if (!strcmp(tz, "GMT0")) timezone = _strdup("0");
                else if (!strcmp(tz, "MET-1MEST-2,M3.5.0/2,M10.5.0/3")) timezone = _strdup("+1");
                else if (!strcmp(tz, "CET-1CEST-2,M3.5.0/2,M10.5.0/3")) timezone = _strdup("+1");
                else if (!strcmp(tz, "CET-1CEST-2,M3.5.0/1,M10.5.0/2")) timezone = _strdup("+1");
                else if (!strcmp(tz, "EEST-2EEDT-3,M3.5.0/3,M10.5.0/4")) timezone = _strdup("+2");
                else if (!strcmp(tz, "EET-2EEST-3,M3.5.0/3,M10.5.0/4")) timezone = _strdup("+3");
                else if (!strcmp(tz, "EST5EDT4,M3.2.0/2,M11.1.0/2")) timezone = _strdup("-5");
                else if (!strcmp(tz, "EST5EDT4,M3.2.0/02,M11.1.0/02")) timezone = _strdup("-5");
                else if (!strcmp(tz, "CST6CDT5,M3.2.0/2,M11.1.0/2")) timezone = _strdup("-6");
                else if (!strcmp(tz, "MST7MDT6,M3.2.0/2,M11.1.0/2")) timezone = _strdup("-7");
                else if (!strcmp(tz, "PST8PDT7,M3.2.0/2,M11.1.0/2")) timezone = _strdup("-8");
                else if (!strcmp(tz, "NAST9NADT8,M3.2.0/2,M11.1.0/2")) timezone = _strdup("-9");
                else if (!strcmp(tz, "AKST9AKDT8,M3.2.0/02,M11.1.0/02")) timezone = _strdup("-9");
                else if (!strcmp(tz, "HAST10HADT9,M3.2.0/02,M11.1.0/02")) timezone = _strdup("-10");
                else if (!strcmp(tz, "NST3:30NDT2:30,M3.2.0/0:01,M11.1.0/0:01")) timezone = _strdup("-3:30");
                else if (!strcmp(tz, "AST10ADT9,M3.2.0/2,M11.1.0/2")) timezone = _strdup("-10");
                else if (!strcmp(tz, "CST5CDT4,M4.1.0/0,M10.5.0/1")) timezone = _strdup("-5");
                else if (!strcmp(tz, "EST5")) timezone = _strdup("-5");
                else if (!strcmp(tz, "BRT3BTST2,M10.3.0/0,M2.3.0/0")) timezone = _strdup("-3");
                else if (!strcmp(tz, "AMT4")) timezone = _strdup("-4");
                else if (!strcmp(tz, "AST5ADT4,M10.4.6/2,M2.2.6/2")) timezone = _strdup("-5");
                else if (!strcmp(tz, "FNT2")) timezone = _strdup("-2");
                else if (!strcmp(tz, "CLT4CLST3,M10.2.0/0,M3.2.0/0")) timezone = _strdup("-4");
                else if (!strcmp(tz, "EAST6EASST5,M10.2.0/0,M3.2.0/0")) timezone = _strdup("-6");
                else if (!strcmp(tz, "EET-2EEST-3,M4.5.5/0,M9.5.4/24")) timezone = _strdup("+2");
                else if (!strcmp(tz, "EET-2")) timezone = _strdup("+2");
                else if (!strcmp(tz, "CST-8")) timezone = _strdup("+8");
                else if (!strcmp(tz, "KST-9")) timezone = _strdup("+9");
                else if (!strcmp(tz, "IST-2IDT-3,M3.5.5/2,M9.3.0/2")) timezone = _strdup("+2");
                else if (!strcmp(tz, "IRST-3:30")) timezone = _strdup("+3:30");
                else if (!strcmp(tz, "SGT-8")) timezone = _strdup("+8");
                else if (!strcmp(tz, "CST-9:30CST-10:30,M10.5.0/2,M3.5.0/3 ")) timezone = _strdup("+10:30");
                else if (!strcmp(tz, "CST6CDT5,M3.2.0/02,M11.1.0/02")) timezone = _strdup("-6");
                else if (!strcmp(tz, "MST7MDT6,M3.2.0/02,M11.1.0/02")) timezone = _strdup("-7");
                else if (!strcmp(tz, "PST8PDT7,M3.2.0/02,M11.1.0/02")) timezone = _strdup("-8");
                else if (!strcmp(tz, "AST4ADT3,M3.2.0/2,M11.1.0/2")) timezone = _strdup("-4");
                if (tz) free((void*)tz);
            }
        }
        if (last) {
            class ITask * task = new TaskWriteConfigDevice(sdkprovisioning->database, this->stunserver, this->turnserver, this->turnusr, this->turnpwd, this->coder, this->tlsProfile, this->ntp1, this->ntp2, this->timezone, this->code, this->mac);
            configList.push_back(task);
            if (!configTask){
                task->Start(&taskWriteConfigDevice);
                configTask = task;
            }
        }
        if (bufferOrg) free((void*)bufferOrg);
    }
    else {
        sdkprovisioning->Log("ProvisioningDevices(%p) JSON config could not be decoded!", this);
        if (session) session->ProvisioningDevicesCompleted(this, false, "JSON config could not be decoded!");
        if (bufferOrg) free((void*)bufferOrg);
    }
}
const char * ProvisioningDevices::GetManagerSysClientPassword()
{
    return this->password;
}
void ProvisioningDevices::SysClientClosed(class ISysclient * sysclient)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::SysClientClosed", this);
    delete sysclient;
    this->sysclient = NULL;
    if (stopping) TryClose();
}

void ProvisioningDevices::DatabaseWritePasswordComplete(class TaskWritePassword * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabaseWritePasswordComplete", this);
    if (passwordTask == task) passwordTask = NULL;
    delete task;
    if (stopping) TryClose();
}

void ProvisioningDevices::DatabaseWritePasswordFailed(class TaskWritePassword * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabaseWritePasswordFailed", this);
    if (passwordTask == task) passwordTask = NULL;
    delete task;
    if (stopping) TryClose();
}

void ProvisioningDevices::DatabaseReadPasswordComplete(class TaskReadPassword * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabaseReadPasswordComplete", this);
    if (this->password) free((void*)this->password);
    this->password = _strdup(task->password);
    if (passwordTask == task) passwordTask = NULL;
    delete task;
    if (stopping) TryClose();
    else {
        sysclient->SetAdminPassword(this->password);
        sysclient->SendIdentify(NULL, reconnect ? NULL : code, mac, "SDKProvisioning", "1", "{ \"type\": \"PHONE\" }");
    }
}

void ProvisioningDevices::DatabaseReadPasswordFailed(class TaskReadPassword * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabaseReadPasswordFailed", this);
    if (passwordTask == task) passwordTask = NULL;
    delete task;
    if (stopping) TryClose();
}

void ProvisioningDevices::DatabaseWriteConfigComplete(class TaskWriteConfigDevice * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabaseWriteConfigComplete", this);
    configList.remove(task);
    if (configTask == task) configTask = NULL;
    delete task;
    if (stopping) {
        while (configList.size() > 0) {
            class ITask * taskk = configList.front();
            configList.remove(taskk);
            delete taskk;
        }
        TryClose();
    }
    else if (configList.size() > 0) {
        configTask = configList.front();
        configTask->Start(&taskWriteConfigDevice);
    }
}

void ProvisioningDevices::DatabaseWriteConfigFailed(class TaskWriteConfigDevice * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabaseWriteConfigFailed", this);
    configList.remove(task);
    if (configTask == task) configTask = NULL;
    delete task;
    if (stopping) {
        while (configList.size() > 0) {
            class ITask * taskk = configList.front();
            configList.remove(taskk);
            delete taskk;
        }
        TryClose();
    }
    //else if (sysclient) sysclient->Close();
    else if (configList.size() > 0) {
        configTask = configList.front();
        configTask->Start(&taskWriteConfigDevice);
    }
    else{
        char * command = (char*)alloca(1024);
        _snprintf(command, 1024, "Saving config for device %s failed!", this->mac);
        class ITask * task = new TaskWriteHistory(sdkprovisioning->database, command, false, "");
        historyList.push_back(task);
        if (!historyTask){
            task->Start(&taskWriteHistory);
            historyTask = task;
        }
    }
}

void ProvisioningDevices::DatabasWriteHistoryComplete(class TaskWriteHistory * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabasWriteHistoryComplete", this);
    historyList.remove(task);
    if (historyTask == task) historyTask = NULL;
    delete task;
    if (stopping) {
        while (historyList.size() > 0) {
            class ITask * taskk = historyList.front();
            historyList.remove(taskk);
            delete taskk;
        }
        TryClose();
    }
    else if (historyList.size() > 0 && !historyTask){
        class ITask * task = historyList.front();
        task->Start(&taskWriteHistory);
        historyTask = task;
    }
    else if (!reconnect && session) session->ProvisioningDevicesCompleted(this, true, NULL);
}

void ProvisioningDevices::DatabaseWriteHistoryFailed(class TaskWriteHistory * task)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::DatabaseWriteHistoryFailed", this);
    historyList.remove(task);
    if (historyTask == task) historyTask = NULL;
    delete task;
    if (stopping) {
        while (historyList.size() > 0) {
            class ITask * taskk = historyList.front();
            historyList.remove(taskk);
            delete taskk;
        }
        TryClose();
    }
    else if (historyList.size() > 0) {
        historyTask = historyList.front();
        historyTask->Start(&taskWriteHistory);
    }
    else if (!reconnect && session) session->ProvisioningDevicesCompleted(this, false, NULL);
}

void ProvisioningDevices::TryClose()
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::TryClose session:%p", this, session);
    this->stopping = true;
    if (historyTask) return;
    else if (configTask) return;
    else if (passwordTask) return;
    else if (sysclient) sysclient->Close();
    else if (configList.size() > 0) return;
    else if (historyList.size() > 0) return;
    else {
        if (session) session->ProvisioningDevicesCompleted(this, true, NULL);
        sdkprovisioning->ProvisioningDevicesClosed(this);
    }
}

void ProvisioningDevices::Close(bool cancel)
{
    sdkprovisioning->Log("ProvisioningDevices(%p)::Close", this);
    this->cancel = cancel;
    TryClose();
}

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*														class DeDeprovisioningDevices														 */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
DeprovisioningDevices::DeprovisioningDevices(class SDKProvisioning * sdkprovisioning, class SDKProvisioningSession * session, const char * mac) :
taskDeleteDevice(this, &DeprovisioningDevices::DatabaseDeleteDeviceComplete, &DeprovisioningDevices::DatabaseDeleteDeviceFailed)
{
    this->mac = _strdup(mac);
    this->stopping = false;
    this->cancel = false;
    this->success = false;
    this->sdkprovisioning = sdkprovisioning;
    this->session = session;
    this->database = sdkprovisioning->database;
    this->currentTask = NULL;
}

DeprovisioningDevices::~DeprovisioningDevices()
{
    if (mac) free((void*)mac);
    mac = NULL;
}

void DeprovisioningDevices::Start()
{
    if (stopping) TryClose();
    else{
        currentTask = new TaskDeleteDevice(sdkprovisioning->database, mac);
        currentTask->Start(&taskDeleteDevice);
    }
}

void DeprovisioningDevices::Stop()
{
    TryClose();
}

void DeprovisioningDevices::DatabaseDeleteDeviceComplete(class TaskDeleteDevice * task)
{
    delete task;
    currentTask = NULL;
    if (stopping) TryClose();
}

void DeprovisioningDevices::DatabaseDeleteDeviceFailed(class TaskDeleteDevice * task)
{
    delete task;
    currentTask = NULL;
    TryClose();
}

void DeprovisioningDevices::TryClose()
{
    this->stopping = true;
    if (currentTask) return;
    else session->DeprovisioningDevicesCompleted(this, success, NULL);
}

void DeprovisioningDevices::Close(bool cancel)
{
    this->cancel = cancel;
    TryClose();
}

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*														class GetConfig														 */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
GetConfig::GetConfig(class SDKProvisioning * sdkprovisioning, const char * type, const char * mac) :
taskReadConfigDevice(this, &GetConfig::DatabaseReadConfigComplete, &GetConfig::DatabaseReadConfigFailed, &GetConfig::DatabaseReadConfigProgress)
{
    this->type = _strdup(type);
    this->mac = _strdup(mac);
    this->sdkprovisioning = sdkprovisioning;
    this->hwid = NULL;
    this->username = NULL;
    this->userpwd = NULL;
    this->domain = NULL;
    this->dns = NULL;
    this->stunserver = NULL;
    this->turnserver = NULL;
    this->turnusr = NULL;
    this->turnpwd = NULL;
    this->coder = NULL;
    this->tlsProfile = NULL;
    this->ntp1 = NULL;
    this->ntp2 = NULL;
    this->timezone = NULL;
    this->get = NULL;
    this->currentTask = NULL;
}

GetConfig::~GetConfig()
{
    if (type) free((void*)type);
    if (mac) free((void*)mac);
    if (hwid) free((void*)hwid);
    if (username) free((void*)username);
    if (userpwd) free((void*)userpwd);
    if (domain) free((void*)domain);
    if (dns) free((void*)dns);
    if (stunserver) free((void*)stunserver);
    if (turnserver) free((void*)turnserver);
    if (turnusr) free((void*)turnusr);
    if (turnpwd) free((void*)turnpwd);
    if (coder) free((void*)coder);
    if (tlsProfile) free((void*)tlsProfile);
    if (ntp1) free((void*)ntp1);
    if (ntp2) free((void*)ntp2);
    if (timezone) free((void*)timezone);
    type = NULL; mac = NULL; hwid = NULL; username = NULL; userpwd = NULL; domain = NULL; dns = NULL; stunserver = NULL; turnserver = NULL; turnusr = NULL; turnpwd = NULL; coder = NULL; tlsProfile = NULL; ntp1 = NULL; ntp2 = NULL; timezone = NULL;
}

void GetConfig::WebserverGetRequestAcceptComplete(IWebserverGet * const webserverGet)
{
    DBG_GET(("MyGetHandler::WebserverGetRequestAcceptComplete"));
    get = webserverGet;
	
	//Check if the requested config file is the right one
    if (!strcmp(type, "cfg")){
        if (strlen(mac) >= 10) {
            currentTask = new TaskReadConfigDevice(sdkprovisioning->database, mac);
            currentTask->Start(&taskReadConfigDevice);
        }
        else get->Cancel(WSP_CANCEL_NOT_FOUND);
    }
    else get->Cancel(WSP_CANCEL_NOT_FOUND);
}

void GetConfig::WebserverGetSendResult(IWebserverGet * const webserverGet)
{
    this->SendNextPart(webserverGet);
}

void GetConfig::SendNextPart(IWebserverGet * const webserverGet)
{
    DBG_GET(("GetConfig::SendNextPart"));
    if (dataSend < dataSize) {
        size_t dataSizeDiff = dataSize - dataSend;
        size_t sendSize = dataSizeDiff > WS_MAX_DATA_SIZE ? WS_MAX_DATA_SIZE : dataSizeDiff;
        webserverGet->Send((void *)(dataBuffer + dataSend), sendSize);
        dataSend += sendSize;
        if (dataSend == dataSize)
            webserverGet->Close();
    }
}

void GetConfig::WebserverGetCloseComplete(IWebserverGet * const webserverGet)
{
    DBG_GET(("GetConfig::WebserverGetCloseComplete"));
    delete webserverGet;
    get = 0;
    TryClose();
}

void GetConfig::TryClose()
{
    DBG_GET(("GetConfig::TryClose"));
    if (currentTask) return;
    else if (this->get) get->Close();
    else sdkprovisioning->GetConfigClosed(this);
}

void GetConfig::Close()
{
    DBG_GET(("GetConfig::Close"));
    TryClose();
}

void GetConfig::DatabaseReadConfigComplete(class TaskReadConfigDevice * task)
{
    delete task;
    currentTask = 0;

    char data[32768], *b = data, *e = b + sizeof(data);
    b += _snprintf(b, e - b, "Print Config to send it to the phone...");
    dataBuffer = (byte*)data;
    dataSize = strlen(data);
    dataSend = 0;
    this->get->SetTransferInfo(WSP_RESPONSE_TEXT, dataSize);
    this->SendNextPart(this->get);
}

void GetConfig::DatabaseReadConfigProgress(class TaskReadConfigDevice * task, dword progress)
{
    //Parse Configs
    const char * pwd;
    if (!this->hwid) task->GetEntry(this->hwid, this->username, pwd, this->domain, this->dns, this->stunserver, this->turnserver, this->turnusr, this->turnpwd, this->coder, this->tlsProfile, this->ntp1, this->ntp2, this->timezone);
    this->userpwd = sdkprovisioning->DecryptPassword(pwd);

    free((void*)pwd);
}

void GetConfig::DatabaseReadConfigFailed(class TaskReadConfigDevice * task)
{
    delete task;
    currentTask = 0;
    TryClose();
}
