
/*---------------------------------------------------------------------------*/
/* sdkprovisioning.h                                                         */
/* copyright (c) innovaphone 2015                                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

class SDKProvisioningService : public AppService {

    class IIoMux * iomux;
    class ISocketProvider * localSocketProvider;
    class ISocketProvider * tcpSocketProvider;
    class ISocketProvider * tlsSocketProvider;
    class IWebserverPluginProvider * webserverPluginProvider;
    class IDatabaseProvider * databaseProvider;

public:
    SDKProvisioningService(class IIoMux * const iomux, class ISocketProvider * localSocketProvider, class ISocketProvider * tcpSocketProvider, class ISocketProvider * tlsSocketProvider, IWebserverPluginProvider * const webserverPluginProvider, class IDatabaseProvider * databaseProvider, AppServiceArgs * args);
    ~SDKProvisioningService();

    virtual class AppInstance * CreateInstance(AppInstanceArgs * args) override;
    virtual void AppServiceApps(istd::list<AppServiceApp> * appList) override;
    virtual void AppInstancePlugins(istd::list<AppInstancePlugin> * pluginList) override;
};

typedef std::list<class SDKProvisioningSession *> SDKProvisioningSessionList;
typedef std::list<class ProvisioningDevices *> ProvisioningList;
typedef std::list<class DeprovisioningDevices *> DeprovisioningList;
typedef std::list<class GetConfig *> GetConfigsList;
typedef std::list<class ITask *> TasksList;

class SDKProvisioning : public UWebserverPlugin, public UDatabase, public AppInstance, public JsonApiContext
{
    class IWebserverPlugin * webserverPlugin;
    bool stopping;
    SDKProvisioningSessionList sessions;
    GetConfigsList getConfigsList;
    class ITask * tableSetup;

    virtual void WebserverPluginClose(IWebserverPlugin * plugin, wsp_close_reason_t reason, bool lastUser);
    void WebserverPluginHttpListenResult(IWebserverPlugin * plugin, ws_request_type_t requestType, char * resourceName, const char * registeredPathForRequest, size_t dataSize);
    void WebserverPluginWebsocketListenResult(IWebserverPlugin * plugin, const char * path, const char * registeredPathForRequest, const char * host);
    void DatabaseConnectComplete(IDatabase * const database);
    void DatabaseShutdown(IDatabase * const database, db_error_t reason);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset);
    void TryStop();
    void DatabaseReadDevicesComplete(class TaskReadDevices * task);
    void DatabaseReadDevicesFailed(class TaskReadDevices * task);
    void DatabaseReadDevicesProgress(class TaskReadDevices * task, dword progress);


public:
    SDKProvisioning(IIoMux * const iomux, ISocketProvider * localSocketProvider, ISocketProvider * tcpSocketProvider, ISocketProvider * tlsSocketProvider, IWebserverPluginProvider * const webserverPluginProvider, IDatabaseProvider * databaseProvider, SDKProvisioningService * service, AppInstanceArgs * args);
    ~SDKProvisioning();
    void Stop();
    void ServerCertificateUpdate(const byte * cert, size_t certLen);
    const char * GetAppPassword();
    void DatabaseInitComplete(class TaskDatabaseInit * task);
    void DatabaseInitFailed(class TaskDatabaseInit * task);
    void SDKProvisioningSessionClosed(class SDKProvisioningSession * session);
    void GetConfigClosed(class GetConfig * req);
	void ReopenSysclient()
    void ProvisioningDevicesClosed(class ProvisioningDevices * provisioning);

    void InstanceConfigClosed(class SDKProvisioningInstanceConfig * iconfig);
    void TaskCompleteConfig();
    void TaskFailedConfig();
    void TaskProgressConfig();
    void ConfigChanged();

    const char * EncryptPassword(const char * password);
    const char * DecryptPassword(const char * data);
    void Hex2Str(char out[], const char * hex);

    class IDatabase * database;
    SDKProvisioningSessionList pbxSessions;
    class IIoMux * iomux;
    class ISocketProvider * tcpSocketProvider;
    class ISocketProvider * tlsSocketProvider;
    class SDKProvisioningInstanceConfig  * instanceConfig;
    bool initConfig;
    const char * appURL;
    ProvisioningList pList;
    class ITask * sysclientTask;
    bool reopenSysclient;
    class UTaskTemplate<SDKProvisioning, class TaskDatabaseInit> taskDatabaseInit;
    class UTaskTemplate<SDKProvisioning, class TaskReadDevices> taskReadDevices;
};


class SDKProvisioningSession : public AppWebsocket, public UServicesApi {
    class SDKProvisioning * sdkprovisioning;
    bool closing;
    bool appWebsocketClosed;
    class ITask * currentTask;
    DeprovisioningList dList;

    void AppWebsocketServiceInfo(const char * app, class json_io & msg, word base) override;
    char * AppWebsocketPassword();
    bool AppWebsocketConnectComplete(class json_io & msg, word info) override;
    void AppWebsocketMessage(class json_io & msg, word base, const char * mt, const char * src);
    void AppWebsocketClosed();
    void AppWebsocketSendResult(){ };
    void TryClose();
    void TaskFinished(class ITask * task);
    void DatabaseWriteRegistrationComplete(class TaskWriteRegistration * task);
    void DatabaseWriteRegistrationFailed(class TaskWriteRegistration * task);
    void DatabaseReadHistoryComplete(class TaskReadHistory * task);
    void DatabaseReadHistoryFailed(class TaskReadHistory * task);
    void DatabaseReadHistoryProgress(class TaskReadHistory * task, dword progress);
    void DatabaseReadDevicesComplete(class TaskReadDevices * task);
    void DatabaseReadDevicesFailed(class TaskReadDevices * task);
    void DatabaseReadDevicesProgress(class TaskReadDevices * task, dword progress);
    void DatabaseClearHistoryComplete(class TaskClearHistory * task);
    void DatabaseClearHistoryFailed(class TaskClearHistory * task);
    void ServicesApiUpdated(class IServicesApi * servicesApi);
    void ServicesApiClosed(class IServicesApi * servicesApi);

    class UTaskTemplate<SDKProvisioningSession, class TaskWriteRegistration> taskWriteRegistration;
    class UTaskTemplate<SDKProvisioningSession, class TaskReadHistory> taskReadHistory;
    class UTaskTemplate<SDKProvisioningSession, class TaskReadDevices> taskReadDevices;
    class UTaskTemplate<SDKProvisioningSession, class TaskClearHistory> taskClearHistory;

public:
    SDKProvisioningSession(class SDKProvisioning * sdkprovisioning, class IWebserverPlugin * webserverPlugin);
    ~SDKProvisioningSession();
    void Close();
    void MessageComplete(class json_io & msg, char * buffer);
    void ProvisioningDevicesCompleted(class ProvisioningDevices * pd, bool result, const char * error);
    void DeprovisioningDevicesCompleted(class DeprovisioningDevices * dd, bool result, const char * error);
    char * currentSrc;
    bool rcv;
    ProvisioningList pList;
    class IServicesApi * services;
    const char * url;
};


class ProvisioningDevices : public USysclient {
protected:
    const char * code;
    const char * mac;
    const char * password;
    class ITask * historyTask;
    class ITask * configTask;
    class ITask * passwordTask;
    class SDKProvisioning * sdkprovisioning;
    class SDKProvisioningSession * session;
    class IDatabase * database;
    TasksList configList;
    TasksList historyList;
    class UTask * user;
    bool stopping;
    bool cancel;
    bool success;
    const char * stunserver;
    const char * turnserver;
    const char *  turnusr;
    const char * turnpwd;
    const char * coder;
    const char * tlsProfile;
    const char * ntp1;
    const char * ntp2;
    const char * timezone;
    bool reconnect;
    void TryClose();

    void DatabaseWritePasswordComplete(class TaskWritePassword * task);
    void DatabaseWritePasswordFailed(class TaskWritePassword * task);
    void DatabaseReadPasswordComplete(class TaskReadPassword * task);
    void DatabaseReadPasswordFailed(class TaskReadPassword * task);
    void DatabaseWriteConfigComplete(class TaskWriteConfigDevice * task);
    void DatabaseWriteConfigFailed(class TaskWriteConfigDevice * task);
    void DatabasWriteHistoryComplete(class TaskWriteHistory * task);
    void DatabaseWriteHistoryFailed(class TaskWriteHistory * task);
    class UTaskTemplate<ProvisioningDevices, class TaskWritePassword> taskWritePassword;
    class UTaskTemplate<ProvisioningDevices, class TaskReadPassword> taskReadPassword;
    class UTaskTemplate<ProvisioningDevices, class TaskWriteConfigDevice> taskWriteConfigDevice;
    class UTaskTemplate<ProvisioningDevices, class TaskWriteHistory> taskWriteHistory;

public:
    ProvisioningDevices(class SDKProvisioning * sdkprovisioning, class SDKProvisioningSession * session, const char * mac, const char * code, bool reconnect);
    virtual ~ProvisioningDevices();
    void SessionClosed(class SDKProvisioningSession * session);
    void Start();
    void Stop();
    void Close(bool cancel);
    class ISysclient * sysclient;
    void SysclientConnected(class ISysclient * sysclient);
    void SetProvisioningCode(const char * provisioningCode);
    void SetManagerSysClientPassword(const char * password);
    void SetManagerSysClient2Password(const char * password);
    void SetPasswords(const char * admin_pwd);
    void SetConfig(char * buffer);
    const char * GetManagerSysClientPassword();
    void SysClientClosed(class ISysclient * sysclient);
};

class DeprovisioningDevices {
protected:
    const char * mac;
    class ITask * currentTask;
    class SDKProvisioning * sdkprovisioning;
    class SDKProvisioningSession * session;
    class IDatabase * database;
    class UTask * user;
    bool stopping;
    bool cancel;
    bool success;
    void TryClose();

    void DatabaseDeleteDeviceComplete(class TaskDeleteDevice * task);
    void DatabaseDeleteDeviceFailed(class TaskDeleteDevice * task);
    class UTaskTemplate<DeprovisioningDevices, class TaskDeleteDevice> taskDeleteDevice;

public:
    DeprovisioningDevices(class SDKProvisioning * sdkprovisioning, class SDKProvisioningSession * session, const char * mac);
    virtual ~DeprovisioningDevices();
    void Start();
    void Stop();
    void Close(bool cancel);
};

class GetConfig : public UWebserverGet {
protected:
    const char * type;
    const char * mac;
    const char * hwid;
    const char * username;
    const char * userpwd;
    const char * domain;
    const char * dns;
    const char * stunserver;
    const char * turnserver;
    const char *  turnusr;
    const char * turnpwd;
    const char * coder;
    const char * tlsProfile;
    const char * ntp1;
    const char * ntp2;
    const char * timezone;
    class SDKProvisioning * sdkprovisioning;
    class IWebserverGet * get;
    class ITask * currentTask;
    byte * dataBuffer;
    size_t dataSize;
    size_t dataSend;
    void TryClose();
    void DatabaseReadConfigComplete(class TaskReadConfigDevice * task);
    void DatabaseReadConfigProgress(class TaskReadConfigDevice * task, dword progress);
    void DatabaseReadConfigFailed(class TaskReadConfigDevice * task);
    class UTaskTemplate<GetConfig, class TaskReadConfigDevice> taskReadConfigDevice;

public:
    GetConfig(class SDKProvisioning * sdkprovisioning, const char * type, const char * mac);
    ~GetConfig();

    void WebserverGetRequestAcceptComplete(IWebserverGet * const webserverGet);
    void WebserverGetSendResult(IWebserverGet * const webserverGet);
    void SendNextPart(IWebserverGet * const webserverGet);
    void WebserverGetCloseComplete(IWebserverGet * const webserverGet);

    void Close();
};
