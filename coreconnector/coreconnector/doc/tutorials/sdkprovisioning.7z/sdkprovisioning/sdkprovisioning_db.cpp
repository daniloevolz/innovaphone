/*---------------------------------------------------------------------------*/
/* sdkprovisioning_db.cpp                                                       */
/* copyright (c) innovaphone 2016                                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

#include <string>
#include "platform/platform.h"
#include "common/interface/database.h"
#include "common/interface/task.h"
#include "common/interface/time.h"
#include "common/interface/guuid.h"
#include "common/lib/tasks_postgresql.h"
#include "common/ilib/json.h"
#include "common/ilib/str.h"
#include "sdkprovisioning_db.h"

ProvisioningTaskDatabaseInit::ProvisioningTaskDatabaseInit(IDatabase * database) :
initRegistrations(database, "registrations"),
initConfigs(database, "configs"),
initHistory(database, "history")
{
    // charts
    initRegistrations.AddColumn("id", "BIGSERIAL PRIMARY KEY NOT NULL");
    initRegistrations.AddColumn("code", "VARCHAR UNIQUE NOT NULL");
    initRegistrations.AddColumn("mac", "VARCHAR UNIQUE NOT NULL");
    initRegistrations.AddColumn("password", "VARCHAR");
    initRegistrations.AddColumn("hwid", "VARCHAR");
    initRegistrations.AddColumn("username", "VARCHAR");
    initRegistrations.AddColumn("usrpwd", "VARCHAR");
    initRegistrations.AddColumn("domain", "VARCHAR");
    initRegistrations.AddColumn("dns", "VARCHAR");
    initRegistrations.AddColumn("provisioned", "BOOLEAN");
    initRegistrations.AddColumn("last_request", "BIGINT");

    initConfigs.AddColumn("id", "BIGSERIAL PRIMARY KEY NOT NULL");
    initConfigs.AddColumn("registration_id", "BIGSERIAL REFERENCES registrations(id) ON DELETE CASCADE NOT NULL");
    initConfigs.AddColumn("stunserver", "VARCHAR");
    initConfigs.AddColumn("turnserver", "VARCHAR");
    initConfigs.AddColumn("turnusr", "VARCHAR");
    initConfigs.AddColumn("turnpwd", "VARCHAR");
    initConfigs.AddColumn("coder", "VARCHAR");
    initConfigs.AddColumn("tls_profile", "VARCHAR");
    initConfigs.AddColumn("ntp1", "VARCHAR");
    initConfigs.AddColumn("ntp2", "VARCHAR");
    initConfigs.AddColumn("timezone", "VARCHAR");
    initConfigs.AddConstraint("const_reg_id", "UNIQUE (registration_id)");

    initHistory.AddColumn("id", "BIGSERIAL PRIMARY KEY NOT NULL");
    initHistory.AddColumn("command", "TEXT");
    initHistory.AddColumn("response", "TEXT");
    initHistory.AddColumn("result", "BOOLEAN");
    initHistory.AddColumn("timestamp", "BIGINT");
}

ProvisioningTaskDatabaseInit::~ProvisioningTaskDatabaseInit()
{
}

void ProvisioningTaskDatabaseInit::Start(class UTask * user)
{
    this->user = user;
    initRegistrations.Start(this);
}

void ProvisioningTaskDatabaseInit::TaskComplete(class ITask * const task)
{
    if (task == &initRegistrations) initConfigs.Start(this);
    else if (task == &initConfigs) initHistory.Start(this);
    else if (task == &initHistory) user->TaskComplete(this);
    else ASSERT(false, "TaskDatabaseInit::TaskComplete");
}

void ProvisioningTaskDatabaseInit::TaskFailed(class ITask * const task)
{
    user->TaskFailed(this);
}


/*---------------------------------------------------------------------------*/
/* TaskWriteRegistration                                                     */
/*---------------------------------------------------------------------------*/

TaskWriteRegistration::TaskWriteRegistration(IDatabase * database, const char * mac, const char * code, const char * hwid, const char * username, const char * password, const char * domain, const char * dns, const char * stunserver, const char * turnserver, const char * turnusr, const char * turnpwd)
{
    this->database = database;
    this->mac = _strdup(mac);
    this->code = _strdup(code);
    this->hwid = _strdup(hwid);
    this->username = _strdup(username);
    this->password = _strdup(password);
    this->domain = _strdup(domain);
    this->dns = _strdup(dns);
    this->stunserver = _strdup(stunserver);
    this->turnserver = _strdup(turnserver);    
    this->turnusr = _strdup(turnusr);
    this->turnpwd = _strdup(turnpwd);
    this->error = false;
}

TaskWriteRegistration::~TaskWriteRegistration()
{
    if (mac) free((char*)mac);
    if (code) free((char*)code);
    if (hwid) free((char*)hwid);
    if (username) free((char*)username);
    if (password) free((char*)password);
    if (domain) free((char*)domain);
    if (dns) free((char*)dns);
    if (stunserver) free((char*)stunserver);
    if (turnserver) free((char*)turnserver);
    if (turnusr) free((char*)turnusr);
    if (turnpwd) free((char*)turnpwd);
    mac = NULL; code = NULL; hwid = NULL; username = NULL; password = NULL; domain = NULL; dns = NULL; stunserver = NULL; turnserver = NULL; turnusr = NULL; turnpwd = NULL;
}

void TaskWriteRegistration::Start(class UTask * user)
{
    this->user = user;    
    this->database->InsertSQL(this, "INSERT INTO registrations (mac, code, hwid, username, usrpwd, domain, dns, provisioned) VALUES(%s, %s, %s, %s, %s, %s, %s, FALSE)  ON CONFLICT(mac) DO UPDATE SET code=%s, hwid=%s, username=%s, usrpwd=%s, domain=%s, dns=%s", mac, code, hwid, username, password, domain, dns, code, hwid, username, password, domain, dns);
//this->database->InsertSQL(this, "INSERT INTO registrations (mac, code, hwid, username, usrpwd, domain, dns) VALUES(%s, %s, %s, %s, %s, %s, %s)", mac, code, hwid, username, password, domain, dns);
}

void TaskWriteRegistration::DatabaseInsertSQLResult(IDatabase * const database, ulong64 id)
{
    user->TaskComplete(this);
}

void TaskWriteRegistration::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    delete dataset;
    user->TaskComplete(this);
}

void TaskWriteRegistration::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskWriteRegistration::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskWriteRegistration::TaskFailed(class ITask * const task)
{
    this->error = true;
    this->database->EndTransaction(this, true);
}

/*---------------------------------------------------------------------------*/
/* TaskWritePassword                                                     */
/*---------------------------------------------------------------------------*/

TaskWritePassword::TaskWritePassword(IDatabase * database, const char * mac, const char * password)
{
    this->database = database;
    this->mac = _strdup(mac);
    this->password = _strdup(password);
    this->error = false;
}

TaskWritePassword::~TaskWritePassword()
{
    if (mac) free((char*)mac);
    if (password) free((char*)password);
    mac = NULL; password = NULL;
}

void TaskWritePassword::Start(class UTask * user)
{
    this->user = user;
    this->database->InsertSQL(this, "UPDATE registrations SET password = %s WHERE mac = %s", password, mac);
}

void TaskWritePassword::DatabaseInsertSQLResult(IDatabase * const database, ulong64 id)
{
    user->TaskComplete(this);
}

void TaskWritePassword::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    delete dataset;
    user->TaskComplete(this);
}

void TaskWritePassword::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskWritePassword::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskWritePassword::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskReadPassword                                                     */
/*---------------------------------------------------------------------------*/

TaskReadPassword::TaskReadPassword(IDatabase * database, const char * mac)
{
    this->database = database;
    this->mac = _strdup(mac);
    this->password = NULL;
    this->error = false;
}

TaskReadPassword::~TaskReadPassword()
{
    if (mac) free((char*)mac);
    if (password) free((char*)password);
    mac = NULL; password = NULL;
}

void TaskReadPassword::Start(class UTask * user)
{
    this->user = user;
    this->database->ExecSQL(this, 0, "SELECT password FROM registrations WHERE mac = %s", mac);
}

void TaskReadPassword::DatabaseInsertSQLResult(IDatabase * const database, ulong64 id)
{
    user->TaskComplete(this);
}

void TaskReadPassword::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    if (!dataset->Eot()) password = _strdup(dataset->GetStringValue(dataset->GetColumnID("password")));
    delete dataset;
    user->TaskComplete(this);
}

void TaskReadPassword::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskReadPassword::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskReadPassword::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskReadDevices                                                     */
/*---------------------------------------------------------------------------*/

TaskReadDevices::TaskReadDevices(IDatabase * database)
{
    this->database = database;
    this->error = false;
}

TaskReadDevices::~TaskReadDevices()
{
}

void TaskReadDevices::Start(class UTask * user)
{
    this->user = user;
    this->database->ExecSQL(this, 0, "SELECT r.*, c.stunserver FROM registrations r LEFT JOIN configs c ON r.id = c.registration_id GROUP BY r.id, c.stunserver");
}

void TaskReadDevices::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    this->dataset = dataset;
    if (dataset->Eot()) {
        user->TaskComplete(this);
        delete dataset;
    }
    else {
        user->TaskProgress(this);
        dataset->FetchNextRow();
    }
}

void TaskReadDevices::GetEntry(const char * & code, const char * & mac, const char * & hwid, const char * & username, bool & pwd, const char * & domain, const char * & dns, bool & provisioned, ulong64 & lastRequest, bool & devicesConfig/*, const char * & turnserver, const char * & turnusr, const char * & turnpwd, const char * & coder, const char * & tlsProfile*/)
{
    if (!dataset->Eot()){
        code = dataset->GetStringValue(dataset->GetColumnID("code"));
        mac = dataset->GetStringValue(dataset->GetColumnID("mac"));
        hwid = dataset->GetStringValue(dataset->GetColumnID("hwid"));
        username = dataset->GetStringValue(dataset->GetColumnID("username"));
        pwd = dataset->GetStringValue(dataset->GetColumnID("usrpwd")) ? (strlen(dataset->GetStringValue(dataset->GetColumnID("usrpwd"))) > 0 ? true : false) : false;
        domain = dataset->GetStringValue(dataset->GetColumnID("domain"));
        dns = dataset->GetStringValue(dataset->GetColumnID("dns"));
        provisioned = dataset->GetBoolValue(dataset->GetColumnID("provisioned"));
        lastRequest = dataset->GetULong64Value(dataset->GetColumnID("last_request"));
        devicesConfig = dataset->GetStringValue(dataset->GetColumnID("stunserver")) ? (strlen(dataset->GetStringValue(dataset->GetColumnID("stunserver"))) > 0 ? true : false) : false;
        /*turnserver = _strdup(dataset->GetStringValue(dataset->GetColumnID("turnserver")));
        turnusr = _strdup(dataset->GetStringValue(dataset->GetColumnID("turnusr")));
        turnpwd = _strdup(dataset->GetStringValue(dataset->GetColumnID("turnpwd")));
        coder = _strdup(dataset->GetStringValue(dataset->GetColumnID("coder")));
        tlsProfile = _strdup(dataset->GetStringValue(dataset->GetColumnID("tls")));*/
    }
}

void TaskReadDevices::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskReadDevices::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskReadDevices::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskWriteConfigDevice                                                     */
/*---------------------------------------------------------------------------*/

TaskWriteConfigDevice::TaskWriteConfigDevice(IDatabase * database, const char * stunserver, const char * turnserver, const char *  turnusr, const char * turnpwd, const char * coder, const char * tlsProfile, const char * ntp1, const char * ntp2, const char * timezone, const char * code, const char * mac)
{
    this->database = database;
    this->code = _strdup(code);
    this->mac = _strdup(mac);
    this->configList = configList;
    this->error = false;
    this->stunserver = _strdup(stunserver);
    this->turnserver = _strdup(turnserver);
    this->turnusr = _strdup(turnusr);
    this->turnpwd = _strdup(turnpwd);
    this->coder = _strdup(coder);
    this->tlsProfile = _strdup(tlsProfile);
    this->ntp1 = _strdup(ntp1);
    this->ntp2 = _strdup(ntp2);
    this->timezone = _strdup(timezone);
}

TaskWriteConfigDevice::~TaskWriteConfigDevice()
{
    if (code) free((char*)code);
    if (mac) free((char*)mac);
    if (stunserver) free((char*)stunserver);
    if (turnserver) free((char*)turnserver);
    if (turnusr) free((char*)turnusr);
    if (turnpwd) free((char*)turnpwd);
    if (coder) free((char*)coder);
    if (tlsProfile) free((char*)tlsProfile);
    if (ntp1) free((char*)ntp1);
    if (ntp2) free((char*)ntp2);
    if (timezone) free((char*)timezone);
    code = NULL; mac = NULL; stunserver = NULL; turnserver = NULL; turnusr = NULL; turnpwd = NULL; coder = NULL; tlsProfile = NULL; ntp1 = NULL; ntp2 = NULL; timezone = NULL;
}

void TaskWriteConfigDevice::Start(class UTask * user)
{
    this->user = user;    
    //this->database->ExecSQL(this, 0, "DELETE FROM configs WHERE registration_id = (SELECT id FROM registrations WHERE code = %s)", code);
    char data[256000];
    unsigned l = this->database->QueryPrint(data, sizeof(data), "INSERT INTO configs (registration_id");
    if (stunserver) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", stunserver, turnserver, turnusr, turnpwd");
    if (coder) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", coder");
    if (tlsProfile) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", tls_profile");
    if (ntp1) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", ntp1, ntp2, timezone");
    l += this->database->QueryPrint(&data[l], sizeof(data) - l, ") VALUES((SELECT id FROM registrations WHERE code=%s)", code);
    if (stunserver) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", %s, %s, %s, %s", stunserver, turnserver, turnusr, turnpwd);
    if (coder) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", %s", coder);
    if (tlsProfile) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", %s", tlsProfile);
    if (ntp1) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", %s, %s, %s", ntp1, ntp2, timezone);
    l += this->database->QueryPrint(&data[l], sizeof(data) - l, ") ON CONFLICT(registration_id) DO UPDATE SET ");
    if (stunserver) l += this->database->QueryPrint(&data[l], sizeof(data) - l, "stunserver=%s, turnserver=%s, turnusr=%s, turnpwd=%s", stunserver, turnserver, turnusr, turnpwd);

    if (coder && stunserver) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", coder=%s", coder);
    else if (coder && !stunserver) l += this->database->QueryPrint(&data[l], sizeof(data) - l, "coder=%s", coder);

    if (tlsProfile && (coder || stunserver)) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", tls_profile=%s", tlsProfile);
    else if (tlsProfile && !coder && !stunserver) l += this->database->QueryPrint(&data[l], sizeof(data) - l, "tls_profile=%s", tlsProfile);

    if (ntp1 && (coder || stunserver || tlsProfile)) l += this->database->QueryPrint(&data[l], sizeof(data) - l, ", ntp1=%s, ntp2=%s, timezone=%s", ntp1, ntp2, timezone);
    else if (ntp1 && !coder && !stunserver&& !tlsProfile) l += this->database->QueryPrint(&data[l], sizeof(data) - l, "ntp1=%s, ntp2=%s, timezone=%s", ntp1, ntp2, timezone);

    data[l] = '\0';
    this->database->InsertSQL(this, "%q", data);
}

void TaskWriteConfigDevice::DatabaseInsertSQLResult(IDatabase * const database, ulong64 id)
{
    user->TaskComplete(this);
}

void TaskWriteConfigDevice::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    delete dataset;
    user->TaskComplete(this);
    //this->database->InsertSQL(this, "INSERT INTO configs (stunserver, turnserver, turnusr, turnpwd, coder, tls_profile, registration_id) VALUES(%s, %s, %s, %s, %s, %s, (SELECT id FROM registrations WHERE code=%s))", stunserver, turnserver, turnusr, turnpwd, coder, tlsProfile, code);
}

void TaskWriteConfigDevice::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskWriteConfigDevice::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskWriteConfigDevice::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskReadConfigDevice                                                     */
/*---------------------------------------------------------------------------*/

TaskReadConfigDevice::TaskReadConfigDevice(IDatabase * database, const char * mac)
{
    this->mac = _strdup(mac);
    this->database = database;
    this->updated = false;
    this->error = false;
}

TaskReadConfigDevice::~TaskReadConfigDevice()
{
    if (mac) free((void*)mac);
    mac = NULL;
}

void TaskReadConfigDevice::Start(class UTask * user)
{
    this->user = user;
    ulong64 now = (ITime::TimeStampMilliseconds()) / 1000;
    this->database->ExecSQL(this, 0, "UPDATE registrations SET provisioned=TRUE, last_request=%llu WHERE mac=%s", now, mac);
}

void TaskReadConfigDevice::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    this->dataset = dataset;
    if (!updated){
        updated = true;
        delete dataset;
        this->database->ExecSQL(this, 0, "SELECT r.*, c.stunserver, c.turnserver, c.turnusr, c.turnpwd, c.ntp1, c.ntp2, c.timezone, c.coder AS coder, c.tls_profile AS tls FROM registrations r LEFT JOIN configs c ON r.id = c.registration_id WHERE r.mac = %s GROUP BY r.id, c.stunserver, c.turnserver, c.turnusr, c.turnpwd, c.ntp1, c.ntp2, c.timezone, c.coder, c.tls_profile", mac);
    }
    else{
        if (dataset->Eot()) {
            user->TaskComplete(this);
            delete dataset;
        }
        else {
            user->TaskProgress(this);
            dataset->FetchNextRow();
        }
    }
}

void TaskReadConfigDevice::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskReadConfigDevice::GetEntry(const char * & hwid, const char * & username, const char * & usrpwd, const char * & domain, const char * & dns, const char * & stunserver, const char * & turnserver, const char * & turnusr, const char * & turnpwd, const char * & coder, const char * & tlsProfile, const char * & ntp1, const char * & ntp2, const char * & timezone)
{
    if (!dataset->Eot()){
        hwid = _strdup(dataset->GetStringValue(dataset->GetColumnID("hwid")));
        username = _strdup(dataset->GetStringValue(dataset->GetColumnID("username")));
        usrpwd = _strdup(dataset->GetStringValue(dataset->GetColumnID("usrpwd")));
        domain = _strdup(dataset->GetStringValue(dataset->GetColumnID("domain")));
        dns = _strdup(dataset->GetStringValue(dataset->GetColumnID("dns")));
        stunserver = _strdup(dataset->GetStringValue(dataset->GetColumnID("stunserver")));
        turnserver = _strdup(dataset->GetStringValue(dataset->GetColumnID("turnserver")));
        turnusr = _strdup(dataset->GetStringValue(dataset->GetColumnID("turnusr")));
        turnpwd = _strdup(dataset->GetStringValue(dataset->GetColumnID("turnpwd")));
        coder = _strdup(dataset->GetStringValue(dataset->GetColumnID("coder")));
        tlsProfile = _strdup(dataset->GetStringValue(dataset->GetColumnID("tls")));
        ntp1 = _strdup(dataset->GetStringValue(dataset->GetColumnID("ntp1")));
        ntp2 = _strdup(dataset->GetStringValue(dataset->GetColumnID("ntp2")));
        timezone = _strdup(dataset->GetStringValue(dataset->GetColumnID("timezone")));
    }
}

void TaskReadConfigDevice::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskReadConfigDevice::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskDeleteDevice                                                     */
/*---------------------------------------------------------------------------*/

TaskDeleteDevice::TaskDeleteDevice(IDatabase * database, const char * mac)
{
    this->mac = _strdup(mac);
    this->database = database;
    this->updated = false;
    this->error = false;
}

TaskDeleteDevice::~TaskDeleteDevice()
{
    if (mac) free((void*)mac);
    mac = NULL;
}

void TaskDeleteDevice::Start(class UTask * user)
{
    this->user = user;
    this->database->ExecSQL(this, 0, "DELETE FROM registrations WHERE mac=%s", mac);
}

void TaskDeleteDevice::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    user->TaskComplete(this);
    delete dataset;
}

void TaskDeleteDevice::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskDeleteDevice::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskDeleteDevice::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskWriteHistory                                                     */
/*---------------------------------------------------------------------------*/

TaskWriteHistory::TaskWriteHistory(IDatabase * database, const char * command, bool result, const char * response)
{
    this->database = database;
    this->command = _strdup(command);
    this->response = _strdup(response);
    this->result = result;
    this->error = false;
}

TaskWriteHistory::~TaskWriteHistory()
{
    if (command) free((char*)command);
    if (response) free((char*)response);
    command = NULL; response = NULL;
}

void TaskWriteHistory::Start(class UTask * user)
{
    this->user = user;
    ulong64 timestamp = (ITime::TimeStampMilliseconds()) / 1000;
    this->database->InsertSQL(this, "INSERT INTO history (command, result, response, timestamp) VALUES(%s, %b, %s, %u)", command, result, response, timestamp);
}

void TaskWriteHistory::DatabaseInsertSQLResult(IDatabase * const database, ulong64 id)
{
    user->TaskComplete(this);
}

void TaskWriteHistory::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    delete dataset;
    user->TaskComplete(this);
}

void TaskWriteHistory::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskWriteHistory::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskWriteHistory::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskReadHistory                                                     */
/*---------------------------------------------------------------------------*/

TaskReadHistory::TaskReadHistory(IDatabase * database)
{
    this->database = database;
    this->error = false;
}

TaskReadHistory::~TaskReadHistory()
{
}

void TaskReadHistory::Start(class UTask * user)
{
    this->user = user;
    this->database->ExecSQL(this, 0, "SELECT * FROM history");
}

void TaskReadHistory::DatabaseInsertSQLResult(IDatabase * const database, ulong64 id)
{
    user->TaskComplete(this);
}

void TaskReadHistory::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    this->dataset = dataset;
    if (dataset->Eot()) {
        user->TaskComplete(this);
        delete dataset;
    }
    else {
        user->TaskProgress(this);
        dataset->FetchNextRow();
    }
}

void TaskReadHistory::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskReadHistory::GetEntry(const char * & command, bool & result, const char * & response, ulong64 & timestamp)
{
    if (!dataset->Eot()){
        command = dataset->GetStringValue(dataset->GetColumnID("command"));
        result = dataset->GetBoolValue(dataset->GetColumnID("result"));
        response = dataset->GetStringValue(dataset->GetColumnID("response"));
        timestamp = dataset->GetULong64Value(dataset->GetColumnID("timestamp"));
    }
}

void TaskReadHistory::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskReadHistory::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}

/*---------------------------------------------------------------------------*/
/* TaskClearHistory                                                     */
/*---------------------------------------------------------------------------*/

TaskClearHistory::TaskClearHistory(IDatabase * database)
{
    this->database = database;
    this->error = false;
}

TaskClearHistory::~TaskClearHistory()
{
}

void TaskClearHistory::Start(class UTask * user)
{
    this->user = user;
    this->database->ExecSQL(this, 0, "DELETE FROM history");
}

void TaskClearHistory::DatabaseExecSQLResult(IDatabase * const database, class IDataSet * dataset)
{
    user->TaskComplete(this);
    delete dataset;
}

void TaskClearHistory::DatabaseError(IDatabase * const database, db_error_t error)
{
    this->error = true;
    user->TaskFailed(this);
}

void TaskClearHistory::TaskComplete(class ITask * const task)
{
    this->error = false;
    user->TaskComplete(this);
}

void TaskClearHistory::TaskFailed(class ITask * const task)
{
    this->error = true;
    user->TaskFailed(this);
}
