/// <reference path="~/sdk/web1/lib1/innovaphone.lib1.js" />
/// <reference path="~/sdk/web0/lib/innovaphone.lib.js" />
/// <reference path="~/sdk/web1/ui1.popup/innovaphone.ui1.popup.js" />
/// <reference path="~/sdk/web1/ui1.scrolling/innovaphone.ui1.scrolling.js" />
/// <reference path="~/sdk/web1/ui1.lib/innovaphone.ui1.lib.js" />
/// <reference path="~/sdk/web1/appwebsocket/innovaphone.appwebsocket.Connection.js" />
/// <reference path="~/sdk/web1/config/innovaphone.config.js" />

var colorSchemes = {
    dark: {
        "--bg0": "#333333",
        "--bg1": "#282828",
        "--bg2": "#333333",
        "--bg3": "#393939",
        "--c1": "#ffffff",
        "--c2": "#939393",
        "--c3": "#8e8e8f",
        "--client-bg1": "#232323",
        "--client-bg2": "#161616",
        "--line2px": "#474747",
        "--input-bg": "#1E1E1E",
        "--input-c": "#ffffff",
        "--button-bg": "#3D3D3D",
        "--button-c": "#ffffff",
        "--disable": "#8e8e8e",
        "--icon-bg": "#ffffff",
        "--border": "#000000",
        "--check-bg": "#319737",
        "--uncheck-bg": "#ffffff",
        "--check-readonly-bg": "#31973766",
        "--uncheck-readonly-bg": "#ffffff66",
        "--row-bg": "#454545",
        "--hover-bg": "#319737cc",
        "--forms": "#1E1E1E",
        "--highlight-bg": "#595959",
        "--orange": "#f59b10",
        "--red": "#ef4d64",
        "--green": "#7cb270",
        "--yellow": "#f59b10",
        "--buttonsvg-bg": "#414141",
        "--accent": "#319737",
        "--error-bg": "#333333"
    },
    light: {
        "--bg0": "#f5f5f5",
        "--bg1": "#e3e3e3",
        "--bg2": "#f5f5f5",
        "--bg3": "#ffffff",
        "--c1": "#000000",
        "--c2": "#404040",
        "--c3": "#8e8e8e",
        "--client-bg1": "#e5e5e5",
        "--client-bg2": "#ffffff",
        "--line2px": "#ffffff",
        "--input-bg": "#ededed",
        "--input-c": "#000000",
        "--button-bg": "#CCCCCC",
        "--button-c": "#000000",
        "--disable": "#d1d1d1",
        "--icon-bg": "#000000",
        "--border": "#e3e3e3",
        "--check-bg": "#319737",
        "--uncheck-bg": "#e0e0e0",
        "--check-readonly-bg": "#31973766",
        "--uncheck-readonly-bg": "#96aeb0b3",
        "--row-bg": "#f5f5f5",
        "--hover-bg": "#7fda84",
        "--forms": "#ededed",
        "--highlight-bg": "#17baae",
        "--orange": "#f59b10",
        "--red": "#ef4d64",
        "--green": "#7cb270",
        "--yellow": "#f59b10",
        "--buttonsvg-bg": "#cccccc",
        "--accent": "#319737",
        "--error-bg": "#eeeeee"
    }
}

var svgIcons = {
    returnSvg: "<path d=\"M10,14,8,16,0,8,8,0l2,2L4,8Z\"/>",
    search: "<path d=\"M19.7,18.6h-.8l-.3-.3a6.5,6.5,0,1,0-.7.7l.3.3v.8l5,5,1.5-1.5Zm-6,0a4.5,4.5,0,1,1,4.5-4.5,4.5,4.5,0,0,1-4.5,4.5Z\" style=\"fill:#aaa\"/>",
    close: "<path d=\"M23.5,10.3l-6,6,6,6L22,23.8l-6-6-6,6L8.5,22.3l6-6-6-6L10,8.8l6,6,6-6Z\"/>",
    okSvg: "<path d=\"M4.2,9.6L0,5.4L1.4,4l2.8,2.8L11,0l1.4,1.4L4.2,9.6z\"></path>",
    arrow: "<path d=\"M5.48,15.37l9-.08L10,20Z\"/>",
    play: "<path d=\"M4.5,20V0l11,10Z\"/>",
    restart: "<path d=\"M3,16.81V3.12a1.14,1.14,0,0,1,1.85-.9l8.07,6.39A1.14,1.14,0,0,1,13,10.35l-8.08,7.3A1.13,1.13,0,0,1,3,16.81ZM16.9,2H15V18h1.9Z\"/>",
    download: "<path d=\"M14.33,6.21l2.17,2.2L10,15,3.5,8.41l2.17-2.2L8.56,9.14V0h2.88V9.14ZM16.5,18H3.5v2h13Z\"></path>",
    info: "<path d=\"M12,5H10V3h2ZM10,15.62,11,9V8H9.31L7,8.69v1.39l2.25-.7L8,16v1h2.12L13,14.92v-.69Z\"></path>",
    myphones: "<path d=\"M3,1H7V17H3ZM19,6V19H1V6H2V18H8V6Zm-6,9H11v2h2Zm0-3H11v2h2Zm3,3H14v2h2Zm0-3H14v2h2Zm1-5H10v4h7Z\"></path>",
    error: "<path d=\"M11.33,12H8.67L8,3.33h4Zm0,2H8.67v2.67h2.66Z\"></path>",
    closeerror: "<path d=\"M7.5,10,1.68,4.18l2.5-2.5L10,7.5l5.82-5.82,2.5,2.5L12.5,10l5.82,5.82-2.5,2.5L10,12.5,4.18,18.32l-2.5-2.5Z\"></path>",
    checkmark: "<path d=\"M4.2,9.6L0,5.4L1.4,4l2.8,2.8L11,0l1.4,1.4L4.2,9.6z\"></path>",
    minus: "<path d=\"M0,8.5H20v3H0Z\"></path>",
    myphones: "<path d=\"M3,1H7V17H3ZM19,6V19H1V6H2V18H8V6Zm-6,9H11v2h2Zm0-3H11v2h2Zm3,3H14v2h2Zm0-3H14v2h2Zm1-5H10v4h7Z\"></path>",
    duration: "<path d=\"M10,2.5A7.5,7.5,0,1,0,17.5,10,7.5,7.5,0,0,0,10,2.5Zm4,9.23H8.53V6h2.19V9.44H14Z\"></path>",
    clearSvg: "<path d=\"M5.68,18.9,0,12.73a5,5,0,0,0,2.62-.52A36.94,36.94,0,0,0,6.81,8.76l5.7,5.82S9,18,7.83,18.62A2.8,2.8,0,0,1,5.68,18.9ZM20,3.09,18,1,11.47,7.63l-2.9-3L6.52,6.76l7.85,8,2.05-2.09-2.9-3Z\"></path>",
}

var timeZones = [
    "-11 Samoa",
    "-10 US-Hawaii-Aleutian",
    "-9:30 French Polynesia",
    "-9 US-Alaska Time",
  "-8 Canada, Mexico, US-Pacific Time",
  "-7 Canada, Mexico, US, Chihuahua, La Paz",
  "-6 Guatemala, El Salvador, Honduras",
  "-5 Bogota, Lima, Quito, Peru, Indiana, Bahamas",
  "-4:30 Venezuela(Caracas)",
  "-4 Canada, Atlantic Time, San Juan",
  "-3:30 Canada-New Foundland(St.Johns)",
  "-3 Greenland, Argentina, Brazil, Brasilia",
  "-2:30 Newfoundland and Labrador",
  "-2 Brazil(no DST), Mid-Atlantic",
  "-1 Portugal(Azores), Cape Verde Islands",
  "0 GMT, Ireland, Portugal, Spain, London",
  "+1 Spain, France, Germany, Italy, Netherlands",
  "+2 Greece, Israel, Russia, Turkey, Ukraine",
  "+3 East Africa Time, Iraq, Russia",
  "+3:30 Iran(Teheran)",
  "+4 Armenia, Georgia, Kazakhstan, Russia",
  "+4:30 Afghanistan(Kabul)",
  "+5 Kazakhstan, Kyrgyzstan, Pakistan",
  "+5:30 India(Calcutta)",
  "+5:45 Nepal(Katmandu)",
  "+6 Kazakhstan, Russia, Bangladesh",
  "+6:30 Myanmar(Naypyitaw)",   
  "+7 Russia, Thailand, Vietnam, Jakarta",
  "+8 China, Singapore, Hong Kong",
  "+8:45 Eucla",
  "+9 Korea(Seoul), Japan(Tokyo), Russia",
  "+9:30 Australia(Adelaide), Australia(Darwin)",
  "+10 Australia, Russia",
  "+10:30 Australia(Lord Howe Islands)",
  "+11 New Caledonia, Russia",
  "+11:30 Norfolk Island",   
  "+12 New Zealand(Wellington,Auckland)",
  "+12:45 New Zealand(Chatham Islands)",
  "+13 Tonga(Nukualofa)",
  "+13:30 Chatham Islands",
  "+14 Kiribati"
]

var timeCodes = [ "-11", "-10", "-9:30", "-9", "-8", "-7", "-6", "-5", "-4:30", "-4", "-3:30", "-3", "-2:30", "-2", "-1", "0", "+1", "+2", "+3", "+3:30", "+4", "+4:30", "+5", "+5:30", "+5:45", "+6", "+6:30", "+7", "+8", "+8:45", "+9", "+9:30", "+10", "+10:30", "+11", "+11:30", "+12", "+12:45", "+13", "+13:30", "+14"]

var innovaphone = innovaphone || {};
innovaphone.sdkprovisioning = innovaphone.sdkprovisioning || function (start) {
    var that = this, body;
    this.createNode("body", "background-color:var(--bg2); overflow:auto");
    var colors = new innovaphone.ui1.CssVariables(colorSchemes, start.scheme);
    start.onschemechanged.attach(function () { colors.activate(start.scheme) });
    var str = new innovaphone.lib1.Languages(innovaphone.sdkprovisioningTexts, start.lang);
    start.onlangchanged.attach(function () { str.activate(start.lang) });
    this.str = str;
    this.config;
    this.timeZonesArray = []
    for (var i = 0; i < timeCodes.length; i++) {
        var obj = new Object();
        obj.timezone = timeZones[i];
        obj.timecode = timeCodes[i];
        that.timeZonesArray[i] = obj;
    }

    this.user = null;
    this.dom = null;

    body = this.add(new innovaphone.ui1.Div("background-color:var(--bg3);", null, "body"));
    this.body = body;
    var menu = body.add(new innovaphone.ui1.Div("position: relative; width: 100%; display: flex; flex: 0 0 auto; flex-direction: row; flex-wrap: wrap; background-color: var(--bg1);"));
    var tab = body.add(new innovaphone.ui1.Div(null, null, "tabs"));
    this.tab = tab;
    var history = new innovaphone.sdkprovisioning.History(that);
    var devices = new innovaphone.sdkprovisioning.Devices(that);
    var configuration = new innovaphone.sdkprovisioning.Config(that);

    var historyTabButton = menu.add(new innovaphone.ui1.Div("background-color: var(--buttonsvg-bg);", null, "buttonMenu"));
    historyTabButton.add(new innovaphone.ui1.SvgInline("position:relative; width:20px; height:20px; fill: var(--icon-bg); margin-right: 5px;", "0 0 20 20", svgIcons.duration, null));
    historyTabButton.add(new innovaphone.ui1.Div("font-size:15px;", "RPS History", "text"))/*.addTranslation(str, "registerphones")*/;
    historyTabButton.addEvent("click", function () {
        historyTabButton.container.style.backgroundColor = "var(--buttonsvg-bg)";
        devicesTabButton.container.style.backgroundColor = "var(--bg2)";
        history.show();
        devices.hide();
        configuration.hide();
    });

    var devicesTabButton = menu.add(new innovaphone.ui1.Div(null, null, "buttonMenu"));
    devicesTabButton.add(new innovaphone.ui1.SvgInline("position: relative; width: 20px; height: 20px; fill: var(--icon-bg); margin: 0px 7px 3px 0px;", "0 0 20 20", svgIcons.myphones, null));
    devicesTabButton.add(new innovaphone.ui1.Div("font-size:15px;", "Devices", "text"))/*.addTranslation(str, "registerphones")*/;
    devicesTabButton.addEvent("click", function () {
        historyTabButton.container.style.backgroundColor = "var(--bg2)";
        devicesTabButton.container.style.backgroundColor = "var(--buttonsvg-bg)";
        history.hide();
        devices.show();
        configuration.hide();
    });

    history.show();
    devices.hide();
    configuration.hide();

    start.onmenustatechanged.attach(function (sender, value) {
        if (value == "open") {
            tab.container.style.filter = "blur(1px)";
            configuration.show();
            menu.container.style.filter = "blur(1px)";
        }
        else {
            tab.container.style.filter = "";
            configuration.hide();
            menu.container.style.filter = "";
        }
    });

    var app = new innovaphone.appwebsocket.Connection(start.url, start.name);
    app.checkBuild = true;
    app.onconnected = appConnected;
    app.onmessage = appMessage;
    var src = new app.src("sdkprovisioning");
    src.onmessage = recv;
    this.app = app;
    this.src = src;
    start.setMenuState("closed");

    function appMessage(message) { }

    function appConnected(domain, user, dn) {
        dom = domain;
        that.dom = domain;
        that.user = user;
        that.config = new innovaphone.Config();
        that.config.evOnConfigItemsReceived.attach(onConfigItemsReceived);
        that.config.evOnConfigLoaded.attach(onConfigLoaded);
        that.config.evOnConfigSaveResult.attach(onConfigSaveResult);
        that.config.init(app);
        history.clear();
        devices.clear();
        src.send({ mt: "ReadHistory" });
    }

    function onConfigItemsReceived(sender) { console.log("onConfigItemsReceived"); }

    function onConfigLoaded(sender) {
        console.log("onConfigLoaded");
        configuration.updatedConfig(that.config.userRPS, that.config.passwordRPS, that.config.urlRPS, that.config.pathRPS, that.config.serverName, that.config.timeoutUpdate, that.config.ntp1, that.config.ntp2, that.config.timezone, that.config.tls);
        src.send({ mt: "ConfigUpdate" });
    }

    function onConfigSaveResult(sender, result) {
        console.log("Config save-result: " + result);
        configuration.savedResult(result);
        src.send({ mt: "ConfigUpdate" });
        if (!result) {
            var popupStyles = new innovaphone.ui1.PopupStyles("popup-background", "popup-header", "popup-main");
            var popup = new innovaphone.ui1.Popup("height:100px; overflow-x: hidden;", popupStyles, 0);
            var close = popup.content.add(new innovaphone.ui1.SvgInline("position:absolute; top:10px; right:10px; width:19px; height:19px; fill: var(--icon-bg); cursor:pointer;", "4 4 24 24", svgIcons.close, null));
            popup.content.add(new innovaphone.ui1.Div("position:absolute; left:10px; top: 40%; right:10px; bottom:10px; text-align:center; word-break:break-word;", null, "textFont")).addTranslation(str, "configsavedfailed");
            close.addEvent("click", function () { popup.close(); });
        }
    }

    function recv(message) {
        console.log("Recv: " + JSON.stringify(message));
        if (message.mt == "EchoResult") { log(message.text); }
        else if (message.mt == "CheckPasswordResult") { configuration.saveConfigAPI(); }
        else if (message.mt == "ReadHistoryInfo") { history.addEntry(message); }
        else if (message.mt == "ReadHistoryResult") { src.send({ mt: "ReadDevices" }); }
        else if (message.mt == "ReadDevicesInfo") { devices.addDevice(message); }
        else if (message.mt == "DeleteDeviceResult") {
            devices.clear();
            src.send({ mt: "ReadDevices" });
        }
        else if (message.mt == "ClearHistoryResult") { history.clear(); }
    }

    function log(text) { that.add(new innovaphone.ui1.Div(null, text)); }

    function addInput(y, text, pw, value) {
        var x = body.add(new innovaphone.ui1.Div("position:absolute; top:" + y + "px", null, "input"));
        var i = x.add(new innovaphone.ui1.Node("input", null, null, "text"));
        i.container.setAttribute("placeholder", text);
        if (value) i.container.setAttribute("value", value);
        if (pw) i.container.setAttribute("type", "password");
        return i;
    }

    function addButton(st, text, cl) { return body.add(new innovaphone.ui1.Div(st, text, cl)); }

    this.httpGet = function (theUrl) {
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open("GET", theUrl, false); // false for synchronous request
        xmlHttp.send(null);
        return xmlHttp.responseText;
    }
};
innovaphone.sdkprovisioning.prototype = innovaphone.ui1.nodePrototype;

innovaphone.sdkprovisioning.History = innovaphone.sdkprovisioning.History || function (admin) {
    var that = this;
    var historyTab = admin.tab.add(new innovaphone.ui1.Div("display:flex; left:10px; top:10px; right:10px; bottom:10px;", null, null));
    var historyCont = new innovaphone.ui1.Div("position:relative; display:flex; flex-direction:column;", null, null);
    var scrollbar = historyTab.add(new innovaphone.ui1.Scrolling("position:absolute; right:0px; bottom:0px; top:0px; left:0px;", -1, 0, 9, "var(--line2px)"));
    scrollbar.add(historyCont);
    var historyMenu = historyTab.add(new innovaphone.ui1.Div(null, null, "sideMenu"));
    addMenuButton(svgIcons.returnSvg, "transform:rotate(90deg); webkitTransform:rotate(90deg);", "0 0 10 16", toTop);
    addMenuButton(svgIcons.returnSvg, "transform:rotate(270deg); webkitTransform:rotate(270deg);", "0 0 10 16", toBottom);
    addMenuButton(svgIcons.clearSvg, null, null, clearHistoryPopup);

    this.show = function () { historyTab.container.style.display = "flex"; }
    this.hide = function () { historyTab.container.style.display = "none"; }
    this.clear = function () {
        while (historyCont.container.childNodes.length > 0) historyCont.container.removeChild(historyCont.container.childNodes[0]);
        var entry = historyCont.add(new innovaphone.ui1.Div("background-color:var(--bg3);", null, "historyEntry"));
        entry.add(new innovaphone.ui1.Div("width:130px;", null, "textHeader")).addTranslation(admin.str, "date");
        entry.add(new innovaphone.ui1.Div("width:60px;", null, "textHeader")).addTranslation(admin.str, "result");
        entry.add(new innovaphone.ui1.Div("width:530px;", null, "textHeader")).addTranslation(admin.str, "command");
        entry.add(new innovaphone.ui1.Div(null, null, "textHeader")).addTranslation(admin.str, "response");
    }

    this.addEntry = function (message) {
        var entry = historyCont.add(new innovaphone.ui1.Div(null, null, "historyEntry"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:130px; padding: 5px;", setValue(message.timestamp), "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:60px; padding: 5px;", null, "text")).addTranslation(admin.str, (message.result ? "ok" : "error"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:530px; padding: 5px;", message.command, "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; padding: 5px;", message.response, "text"));
    }

    function addMenuButton(svgIcon, style, viewbox, onClick) {
        var button = historyMenu.add(new innovaphone.ui1.Div("position:relative; display:flex; flex-direction:row;", null, null));
        button.add(new innovaphone.ui1.SvgInline(style, viewbox ? viewbox : "0 0 20 20", svgIcon, "menuIcon"));
        if (onClick) button.addEvent("click", onClick);
    }

    function setValue(timestamp) {
        if (timestamp.toString().length < 13) timestamp = timestamp * 1000;
        var date = new Date(timestamp);
        var d = date.toLocaleString().replace(",", "").split(".").join("/");
        return d;
    }

    function toTop() { scrollbar.setScrollTop(0); }
    function toBottom() { scrollbar.scrollToBottom(); }
    function clearHistoryPopup() { admin.tab.add(new Popup(this, admin.str, "reallyDeleteHistory", "infoDeleteHistory", clearHistory)); }
    function clearHistory() { admin.src.send({ mt: "ClearHistory" }); }

}
innovaphone.sdkprovisioning.History.prototype = innovaphone.ui1.nodePrototype;

innovaphone.sdkprovisioning.Devices = innovaphone.sdkprovisioning.Devices || function (admin) {
    var devices = this;
    this.devicesArray = [];
    this.selectedDevice = null;
    var devicesTab = admin.tab.add(new innovaphone.ui1.Div("display:flex; left:10px; top:10px; right:10px; bottom:10px;", null, null));
    var devicesCont = new innovaphone.ui1.Div("position:relative; display:flex; flex-direction:column;", null, null);
    var scrollbar = devicesTab.add(new innovaphone.ui1.Scrolling("position:absolute; right:51px; bottom:0px; top:0px; left:0px;", -1, 0, 9, "var(--line2px)"));
    scrollbar.add(devicesCont);
    var devicesMenu = devicesTab.add(new innovaphone.ui1.Div(null, null, "sideMenu"));
    addMenuButton(svgIcons.returnSvg, "transform:rotate(90deg); webkitTransform:rotate(90deg);", "0 0 10 16", toTop);
    addMenuButton(svgIcons.returnSvg, "transform:rotate(270deg); webkitTransform:rotate(270deg);", "0 0 10 16", toBottom);

    this.show = function () { devicesTab.container.style.display = "flex"; }
    this.hide = function () { devicesTab.container.style.display = "none"; }
    this.clear = function () {
        devices.devicesArray = [];
        while (devicesCont.container.childNodes.length > 0) devicesCont.container.removeChild(devicesCont.container.childNodes[0]);
        var entry = devicesCont.add(new innovaphone.ui1.Div("background-color:var(--bg3);", null, "historyEntry"));
        entry.add(new innovaphone.ui1.Div("width:100px;", null, "textHeader")).addTranslation(admin.str, "mac");
        entry.add(new innovaphone.ui1.Div("width:120px;", null, "textHeader")).addTranslation(admin.str, "hwid");
        entry.add(new innovaphone.ui1.Div("width:130px;", null, "textHeader")).addTranslation(admin.str, "username");
        entry.add(new innovaphone.ui1.Div("width:60px;", null, "textHeader")).addTranslation(admin.str, "password");
        entry.add(new innovaphone.ui1.Div("width:130px;", null, "textHeader")).addTranslation(admin.str, "domain");
        entry.add(new innovaphone.ui1.Div("width:130px;", null, "textHeader")).addTranslation(admin.str, "dns");
        entry.add(new innovaphone.ui1.Div("width:180px;", null, "textHeader")).addTranslation(admin.str, "deviceconfig");
        entry.add(new innovaphone.ui1.Div("width:150px;", null, "textHeader")).addTranslation(admin.str, "phonerequests");
        entry.add(new innovaphone.ui1.Div("width:150px;", null, "textHeader")).addTranslation(admin.str, "lastRequest");
    }   

    this.addDevice = function (message) { devices.devicesArray[devices.devicesArray.length] = new Device(message); }

    function Device(message) {
        var device = this;
        this.data = message;
        var entry = devicesCont.add(new innovaphone.ui1.Div("cursor:pointer;", null, "historyEntry"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:100px; padding: 5px;", message.mac, "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:120px; padding: 5px;", message.hwid, "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:130px; padding: 5px;", message.username, "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:60px; padding: 5px;", message.pwd ? "********" : "-", "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:130px; padding: 5px;", message.domain, "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:130px; padding: 5px;", message.dns, "text"));
        entry.add(new innovaphone.ui1.Div("position:relative; width:180px; padding: 5px;", null, "text")).addTranslation(admin.str, message.devicesConfig ? "configreceived" : "noconfig");
        entry.add(new innovaphone.ui1.Div("position:relative; width:150px; padding: 5px;", null, "text")).addTranslation(admin.str, message.provisioned ? "provisioned" : "nophonerequests");
        entry.add(new innovaphone.ui1.Div("position:relative; width:150px; padding: 5px;", formatTimestamp(message.lastRequest), "text"));
        entry.addEvent("click", function () {
            if (!devices.selectedDevice) device.selectDevice();
            else if (device.data.mac == devices.selectedDevice.data.mac) device.deselectDevice();
            else {
                devices.selectedDevice.deselectDevice();
                device.selectDevice();
            }
        });
        this.selectDevice = function(){
            devices.selectedDevice=device;
            entry.container.style.backgroundColor="var(--accent)";
        }
        this.deselectDevice = function(){
            devices.selectedDevice=null;
            entry.container.style.backgroundColor="var(--row-bg)";
        }
    }
    Device.prototype = innovaphone.ui1.nodePrototype;

    function addMenuButton(svgIcon, style, viewbox, onClick) {
        var button = devicesMenu.add(new innovaphone.ui1.Div("position:relative; display:flex; flex-direction:row;", null, null));
        button.add(new innovaphone.ui1.SvgInline(style, viewbox ? viewbox : "0 0 20 20", svgIcon, "menuIcon"));
        if (onClick) button.addEvent("click", onClick);
    }

    function toTop() { scrollbar.setScrollTop(0); }
    function toBottom() { scrollbar.scrollToBottom(); }

    function formatTimestamp(timestamp) {
        if (timestamp) {
            var date = new Date(timestamp * 1000);
            return date.toLocaleString().replace(",", "").split(".").join("/");
        }
        else return "-";
    }
}
innovaphone.sdkprovisioning.Devices.prototype = innovaphone.ui1.nodePrototype;

innovaphone.sdkprovisioning.Config = innovaphone.sdkprovisioning.Config || function (admin) {
    var that = this;
    var configTab = admin.body.add(new innovaphone.ui1.Div("display:none;", null, "menuTab"));
    var configCont = new innovaphone.ui1.Div("position:relative; display:flex; flex-direction:column; flex-wrap:wrap;", null, null);
    var scrollbar = configTab.add(new innovaphone.ui1.Scrolling("position:absolute; right:0px; bottom:0px; top:0px; left:0px;", -1, 0, 9, "var(--line2px)"));
    scrollbar.add(configCont);

    var status = configCont.add(new innovaphone.ui1.Div("position: absolute; top: 10px; right: 10px; height: 30px; width: 150px; display: none; margin-left: auto; flex-direction: row-reverse;", null, "textFont"));

    /*Updates Container*/
    var updatesCont = configCont.add(new innovaphone.ui1.Div(null, null, "configContainer"));
    updatesCont.add(new innovaphone.ui1.Div(null, null, "configTitle")).addTranslation(admin.str, "phoneupdates");
    var upCont = updatesCont.add(new innovaphone.ui1.Div("margin-top: 20px;", null, "configFlexContainer"));
    var inputs1Cont = upCont.add(new innovaphone.ui1.Div("order:0; margin-right: 96px;", null, "configFlexColContainer"));
    var inputs2Cont = upCont.add(new innovaphone.ui1.Div("order:1;", null, "configFlexColContainer"));

    var daysUpdateInput = new AddNumberField(inputs1Cont, "days", 365);
    var hoursUpdateInput = new AddNumberField(inputs1Cont, "hours", 23);
    var minsUpdateInput = new AddNumberField(inputs1Cont, "minutes", 59);

    /*Phone Config*/
    var phoneCont = configCont.add(new innovaphone.ui1.Div(null, null, "configContainer"));

    phoneCont.add(new innovaphone.ui1.Div(null, null, "configTitle")).addTranslation(admin.str, "deviceconfig");
    var pCont = phoneCont.add(new innovaphone.ui1.Div("margin-top: 20px;", null, "configFlexContainer"));
    var phoneCont1 = pCont.add(new innovaphone.ui1.Div("order:0; margin-right: 20px;", null, "configFlexColContainer"));
    var phoneCont2 = pCont.add(new innovaphone.ui1.Div("order:1;", null, "configFlexColContainer"));
    var buttonsphoneCont = phoneCont.add(new innovaphone.ui1.Div("flex-direction:row; display:none; margin-bottom: 10px;border:0px;", null, "configContainer"));
    buttonsphoneCont.add(new innovaphone.ui1.Node("div", "position:relative; text-align:center;margin: 0px 10px 0px auto;", null, "button")).addTranslation(admin.str, "cancel").addEvent("click", onNoPhone).testId("innovaphone-sdkprovisioning-config-no-smtp");
    buttonsphoneCont.add(new innovaphone.ui1.Node("div", "position:relative; text-align:center;margin: 0px 10px; background-color:var(--green);", null, "button")).addTranslation(admin.str, "confirm").addEvent("click", onYesPhone).testId("innovaphone-sdkprovisioning-config-yes-smtp");

    var ntp1Cont, ntp1Input, ntp2Cont, ntp2Input, timezoneCont, timezoneInput;
    [ntp1Cont, ntp1Input] = addInputField(phoneCont1, "ntp1", editInput, buttonsphoneCont);
    [ntp2Cont, ntp2Input] = addInputField(phoneCont1, "ntp2", editInput, buttonsphoneCont);
    [timezoneCont, timezoneInput] = addDropdownField(phoneCont1, "timezone", timeZones, buttonsphoneCont);
    var tlsInput = new Switch(phoneCont2, "tls", "tcp", true, saveConfig);

    function onEditNumber() {
        var enable = (daysUpdateInput.getValue() > 0 || hoursUpdateInput.getValue() > 0 || minsUpdateInput.getValue() > 0) ? true : false;
        daysUpdateInput.setEnable(enable);
        hoursUpdateInput.setEnable(enable);
        minsUpdateInput.setEnable(enable);
        saveConfig();
    }

    function AddNumberField(parent, label, maxValue) {
        var cont = parent.add(new innovaphone.ui1.Div(null, null, "configItemBox"));
        cont.add(new innovaphone.ui1.Div("width: 210px;", null, "textFontConfig")).addTranslation(admin.str, label);
        var contNumber = cont.add(new innovaphone.ui1.Div("position:relative; display:flex; flex-direction:row; flex-wrap:nowrap;", null, null));
        var minusIcon = contNumber.add(new innovaphone.ui1.SvgInline(null, "0 0 20 20", svgIcons.minus, "iconNumber")).testId("innovaphone-sdkprovisioning-config-minus-" + label);
        var input = contNumber.add(new innovaphone.ui1.Node("input", "position:relative; width: 36px; height: 24px; text-align:center;", "1", "text"));
        var plusIcon = contNumber.add(new innovaphone.ui1.SvgInline(null, "0 0 20 20", svgIcons.addSvg, "iconNumber")).testId("innovaphone-sdkprovisioning-config-plus-" + label);
        input.container.readOnly = true;
        minusIcon.addEvent("click", function () {
            if (input.container.value > 0) input.container.value--;
            onEditNumber();
        });
        plusIcon.addEvent("click", function () {
            if (input.container.value < maxValue) input.container.value++;
            onEditNumber();
        });
        this.setValue = function (value) { if (value >= 0 && value <= maxValue) input.container.value = value; }
        this.getValue = function () { return parseInt(input.container.value); }
        this.setEnable = function (status) { input.container.style.color = status ? "var(--c1)" : "var(--c2)"; }
    }
    AddNumberField.prototype = innovaphone.ui1.nodePrototype;

    function addInputField(parent, label, onedit, buttonsCont, pwd) {
        var cont = parent.add(new innovaphone.ui1.Div(null, null, "configItemBox"));
        cont.add(new innovaphone.ui1.Div(null, null, "textFontConfig")).addTranslation(admin.str, label);
        var input = cont.add(new innovaphone.ui1.Node("input", "position:relative; order:1; width: 250px; height: 23px;", null, "text"));
        setInput(input.container, pwd);
        input.container.id = label;
        input.addEvent("click", onedit, buttonsCont);
        return [cont, input];
    }

    function addDropdownField(parent, label, options, buttonsCont) {
        var cont = parent.add(new innovaphone.ui1.Div(null, null, "configItemBox"));
        cont.add(new innovaphone.ui1.Div(null, null, "textFontConfig")).addTranslation(admin.str, label);
        var dd = cont.add(new Dropdown(options)).testId("innovaphone-sdkprovisioning-config-" + label);
        dd.addEvent("change", function () { saveConfig(); });
        return [cont, dd];
    }

    function onYesPhone(ev) {
        ntp1Input.container.setAttribute("vl", ntp1Input.container.value);
        ntp2Input.container.setAttribute("vl", ntp2Input.container.value);
        saveConfig();
        onNoPhone(ev);
    }
    function onNoPhone(ev) {
        setInput(ntp1Input.container, false);
        setInput(ntp2Input.container, false);
        buttonsphoneCont.container.style.display = "none";
    }

    function setInput(input, pwd) {
        input.readOnly = true;
        input.value = input.getAttribute("vl");
        input.style.backgroundColor = "var(--forms)";
        input.style.color = "var(--c1)";
        if (pwd) {
            input.setAttribute("type", "password");
            input.setAttribute("placeholder", "********");
        }
    }

    function editInput(ev, obj) {
        var input = ev.currentTarget;
        if (input.readOnly) {
            input.readOnly = false;
            input.focus();
            var val = input.value;
            input.setAttribute("vl", val);
            input.value = "";
            input.value = val;
            input.style.backgroundColor = "var(--input-bg)";
            input.style.color = "var(--input-c)";
            obj.container.style.display = "flex";
        }
    }

    this.show = function () { configTab.container.style.display = "flex"; }
    this.hide = function () { configTab.container.style.display = "none"; }
    this.cleanConfig = function () { }

    this.updatedConfigResult = function (message) {    }

    this.updatedConfig = function (timeoutUpdate, ntp1, ntp2, timecode, tls) {
        var days = Math.floor(timeoutUpdate / 1440);
        var minsleft = timeoutUpdate - (days * 1440);
        var hours = Math.floor(minsleft / 60);
        var mins = minsleft - (hours * 60);
        daysUpdateInput.setValue(days);
        hoursUpdateInput.setValue(hours);
        minsUpdateInput.setValue(mins);

        ntp1Input.container.value = ntp1;
        ntp1Input.container.setAttribute("vl", ntp1);
        ntp2Input.container.value = ntp2;
        ntp2Input.container.setAttribute("vl", ntp2);
        for (var i = 0; i < admin.timeZonesArray.length; i++) {
            if (timecode == admin.timeZonesArray[i].timecode) {
                timezoneInput.setSelected(admin.timeZonesArray[i].timezone);
                break;
            }
        }
        tlsInput.setValue(tls);
    }

    function saveConfig() { that.saveConfigAPI(); }

    this.saveConfigAPI = function () {
        var days = daysUpdateInput.getValue();
        var hours = hoursUpdateInput.getValue();
        var mins = minsUpdateInput.getValue();
        admin.config.timeoutUpdate = days * 1440 + hours * 60 + mins;

        admin.config.ntp1 = ntp1Input.container.value;
        admin.config.ntp2 = ntp2Input.container.value;
        var tz = timezoneInput.getSelected();
        for (var i = 0; i < admin.timeZonesArray.length; i++) {
            if (tz == admin.timeZonesArray[i].timezone) {
                admin.config.timezone = admin.timeZonesArray[i].timecode;
                break;
            }
        } 
        admin.config.tls = tlsInput.getValue();

        admin.config.save();
        while (status.container.childNodes.length > 0) { status.container.removeChild(status.container.childNodes[0]); }
    }

    this.savedResult = function (result) {
        status.container.style.display = "flex";
        while (status.container.childNodes.length > 0) { status.container.removeChild(status.container.childNodes[0]); }
        if (result) {
            status.add(new innovaphone.ui1.Div("position:relative; font-size:16px;", null, "textFont")).addTranslation(admin.str, "saved");
            status.add(new innovaphone.ui1.SvgInline("position:relative; margin: 1px 5px; width: 12px; height: 12px; fill: white; background-color: var(--check-bg); padding: 4px; border-radius: 50%;", "0 0 12 10", svgIcons.checkmark, "users-icon"));
        }
        else {
            status.add(new innovaphone.ui1.Div("position:relative; font-size:16px;", null, "textFont")).addTranslation(admin.str, "error");
            status.add(new innovaphone.ui1.SvgInline("position:relative; margin: 1px 5px; width: 12px; height: 12px; fill: white; background-color: var(--red); padding: 4px; border-radius: 50%;", "8 8 16 16", svgIcons.close, "users-icon"));
        }
    }

    function Switch(cont, label, labeloff, value, onSwitch) {
        var that = this;
        var swCont = cont.add(new innovaphone.ui1.Div(null, null, "configItemBox"));
        var labelCont = swCont.add(new innovaphone.ui1.Div("width:30px;", null, "textFontConfig")).addTranslation(admin.str, label);
        var switchDiv = swCont.add(new innovaphone.ui1.Switch("position:relative; flex:0 0 auto; height:15px; width:30px; margin: auto 12px auto 5px;", 15, 30, null, null, null, null, "var(--accent)")).testId("innovaphone-sdkprovisioning-config-switch-" + label);
        var labelOffCont = swCont.add(new innovaphone.ui1.Div("color:var(--c2); visibility:hidden;", null, "textFontConfig")).addTranslation(admin.str, labeloff);
        switchDiv.setValue(value);
        switchDiv.addEvent("change", function () {
            labelCont.container.style.visibility = switchDiv.getValue() ? "visible" : "hidden";
            labelOffCont.container.style.visibility = switchDiv.getValue() ? "hidden" : "visible";
            saveConfig();
        });
        this.getValue = function () { return switchDiv.getValue(); }
        this.setValue = function (value) {
            labelCont.container.style.visibility = value ? "visible" : "hidden";
            labelOffCont.container.style.visibility = value ? "hidden" : "visible";
            switchDiv.setValue(value);
        }
    }
    Switch.prototype = innovaphone.ui1.nodePrototype;
}
innovaphone.sdkprovisioning.Config.prototype = innovaphone.ui1.nodePrototype;

function errorMessage(type) {
    var popupStyles = new innovaphone.ui1.PopupStyles("popup-background-error", "popup-header-error", "popup-main-error");
    var popup = new innovaphone.ui1.Popup("position: relative; display: flex; flex-direction: row; 0 0 auto;", popupStyles, 0);
    popup.container.parentNode.style.display = "flex";
    popup.content.container.style.position = "relative";
    popup.content.container.style.display = "flex";
    popup.content.container.style.flex = "1 1 0";
    popup.content.add(new innovaphone.ui1.SvgInline("position: relative; order: 0; width: 25px; height: 25px; fill: var(--red); padding: 7px 5px;", "0 0 20 20", svgIcons.error, null));
    popup.content.add(new innovaphone.ui1.Div("position: relative; margin: 10px 10px 10px 0px; text-align: left; max-width: 244px; word-break: break-word; order: 1; flex: 1 1 0;", type, "textFont"));
    var closeCont = popup.content.add(new innovaphone.ui1.Div("position: relative; margin: 0px; order: 2; flex: 0 0 auto; background-color: var(--red);", null, "textFont"));
    var close = closeCont.add(new innovaphone.ui1.SvgInline("position: relative; width: 15px; height: 15px; fill: white; cursor: pointer; padding: 13px 7px;", "0 0 20 20", svgIcons.closeerror, null));
    close.addEvent("click", function () { popup.close(); });
}

function Popup(main, str, headerText, infoText, onOK) {
    var that = this,
        popup = null,
        headline = null,
        infoTxt = null,
        btnCont = null,
        cancelBtn = null,
        confirmBtn = null;

    function init() {
        that.createNode("div", null, null, "overlay-sdkprovisioning");
        popup = that.add(new innovaphone.ui1.Div(null, null, "popup-sdkprovisioning"));
        headline = popup.add(new innovaphone.ui1.Node("h1")).addTranslation(str, headerText);
        infoTxt = popup.add(new innovaphone.ui1.Div(null, null, "info-text-sdkprovisioning")).addTranslation(str, infoText);
        btnCont = popup.add(new innovaphone.ui1.Div(null, null, "btn-cont-sdkprovisioning"));
        cancelBtn = btnCont.add(new innovaphone.ui1.Node("button", null, null, "button-row-sdkprovisioning")).addTranslation(str, "cancel");
        cancelBtn.addEvent("click", function () {
            str.clear(that);
            that.container.parentNode.removeChild(that.container);
        });
        confirmBtn = btnCont.add(new innovaphone.ui1.Node("button", null, null, "button-row-sdkprovisioning button-red-sdkprovisioning")).addTranslation(str, "ok");
        confirmBtn.addEvent("click", function () {
            str.clear(that);
            that.container.parentNode.removeChild(that.container);
            onOK();
        });
    };

    init();
}
Popup.prototype = innovaphone.ui1.nodePrototype;

function Dropdown(options, value, style) {
    var dropdown = this;
    dropdown.createNode("select", style);

    function addOption(text) {
        var option = dropdown.add(new innovaphone.ui1.Node("option", "background-color: var(--forms); border: none; flex: 1 1 auto; overflow: hidden;", text));
        option.container.value = text;
    }

    this.getSelected = function () {
        return dropdown.container.value;
    }

    this.setSelected = function (option) {
        return dropdown.container.value = option;
    }

    this.updateOptions = function (options) {
        while (dropdown.container.childNodes.length > 0) dropdown.container.removeChild(dropdown.container.childNodes[0]);
        options.forEach(addOption);
    }

    options.forEach(addOption);
    if (value) { if (options.indexOf(value) >= 0) dropdown.container.value = value; }

    return dropdown;
}
Dropdown.prototype = innovaphone.ui1.nodePrototype;

