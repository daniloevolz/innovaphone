var innovaphone = innovaphone || {};
innovaphone.ManagerSDKProvisioningTexts = innovaphone.ManagerSDKProvisioningTexts || {
    en: {
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        pluginTitle: "SDKProvisioning",
        addapp: "Add an app",
        editapp: "Edit the app",
        sdkprovisioning: "SDKProvisioning",
        finish: "Finish",
        pbx: "PBX",
        delTxt: "Delete sth. important",
        reallyDel: "Do you really want to delete?",
        infoTxt: "Are you sure to irrevocably delete this element?"
    },
    de: {
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        pluginTitle: "SDKProvisioning",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
        sdkprovisioning: "SDKProvisioning",
        finish: "Beenden",
        delTxt: "Etwas Wichtiges löschen",
        reallyDel: "Wirklich löschen?",
        infoTxt: "Möchtest du dieses Element wirklich unwiderruflich löschen?"
    },
    es: {
        title: "Nombre",
        sip: "SIP",
        url: "URL",
        del: "Borrar",
        ok: "OK",
        cancel: "Cancelar",
        pluginTitle: "SDKProvisioning",
        addapp: "Añadir una App",
        editapp: "Editar la App",
        sdkprovisioning: "SDKProvisioning",
        finish: "Terminar",
        delTxt: "Borrar algo importante",
        reallyDel: "¿Quiere realmente eliminarlo?",
        infoTxt: "¿Quiere eliminar este elemento de forma definitiva?"
    }
};