var innovaphone = innovaphone || {};
innovaphone.sdkprovisioningTexts = innovaphone.sdkprovisioningTexts || {
    ba: {
    },
    ca: {
    },
    hr: {
    },
    cs: {
    },
    da: {
    },
    en: {
		username: "Username",
		password: "Password",
        cancel: "Cancel",
        confirm: "Confirm",
        saved: "Saved",
        error: "Error",
        reallyDeleteHistory: "Do you really want to clear the history?",
        infoDeleteHistory: "You will not be able to recover the data.",
        mac: "MAC",
        hwid: "Hardware ID",
        domain: "Domain",
        dns: "DNS",
        deviceconfig: "Device Config",
        phonerequests: "Phone Requests",
        configreceived: "Config Received",
        noconfig: "No Config",
        provisioned: "Provisioned",
        nophonerequests: "No Phone Requests",
        date: "Date",
        result: "Result",
        command: "Command",
        response: "Response",
        ok: "OK",
        phoneupdates: "Phone Updates",
        days: "Days",
        hours: "Hours",
        minutes: "Minutes",
        lastRequest: "Last Config Request",
        ntp1: "NTP Server 1",
        ntp2: "NTP Server 2",
        timezone: "Timezone",
        tls: "TLS",
        tcp: "TCP"
    },
    et: {
    },
    fi: {
    },
    de: {
        cancel: "Abbrechen",
        confirm: "Bestätigen",
        saved: "Gespeichert",
        error: "Fehler",
        mac: "MAC",
        hwid: "Hardware-ID",
        domain: "Domäne",
        dns: "DNS",
        date: "Datum",
        ok: "OK",
        days: "Tage",
        hours: "Stunden",
        minutes: "Minuten",
        timezone: "Zeitzone"
    },
    hu: {
    },
    it: {
    },
    lv: {
    },
    mk: {
    },
    no: {
    },
    es: {
        cancel: "Cancelar",
        confirm: "Confirmar",
        saved: "Guardado",
        error: "Error",
        reallyDeleteHistory: "¿Quiere realmente borrar el historial?",
        infoDeleteHistory: "Los datos no podrán ser recuperados.",
        mac: "MAC",
        hwid: "Hardware ID",
        domain: "Dominio",
        dns: "DNS",
        deviceconfig: "Configuración dispositivo",
        phonerequests: "Petición del teléfono",
        configreceived: "Configuración recibida",
        noconfig: "Ninguna configuración",
        provisioned: "Aprovisionado",
        nophonerequests: "Ninguna petición del teléfono",
        date: "Fecha",
        result: "Resultado",
        command: "Comando",
        response: "Respuesta",
        ok: "OK",
        phoneupdates: "Actualizaciones del teléfono",
        days: "Días",
        hours: "Horas",
        minutes: "Minutos",
        lastRequest: "Última petición de configuración",
        ntp1: "Servidor NTP 1",
        ntp2: "Servidor NTP 2",
        timezone: "Uso Horario"
    },
    sv: {
    },
    th: {
    }
};