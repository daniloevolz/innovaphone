#include "platform/platform.h"
#include "common/os/iomux.h"
#include "common/interface/database.h"
#include "common/interface/task.h"
#include "common/interface/json_api.h"
#include "common/lib/config.h"
#include "sdkprovisioning_config.h"


/*---------------------------------------------------------------------------*/
/* SDKProvisioningConfig                                                               */
/*---------------------------------------------------------------------------*/
SDKProvisioningConfig::SDKProvisioningConfig(USDKProvisioningConfig * configUser, IDatabase * const database, IInstanceLog * const log) :
ConfigContext(database, log),
timeoutUpdate(this, "timeoutUpdate", 1440),
ntp1(this, "ntp1", "de.pool.ntp.org"),
ntp2(this, "ntp2", "pool.ntp.org"),
timezone(this, "timezone", "+1"),
tls(this, "tls", true),
taskUpdateConfig(this, &SDKProvisioningConfig::WriteConfigItemsComplete, &SDKProvisioningConfig::WriteConfigItemsFailed)
{
    this->configUser = configUser;
    this->stopping = false;
}

SDKProvisioningConfig::~SDKProvisioningConfig()
{
}

void SDKProvisioningConfig::TryClose()
{
    stopping = true;
    if (tList.size() > 0) return;
    else this->configUser->SDKProvisioningConfigClosed(this);
}

void SDKProvisioningConfig::Init()
{
    ITask * task = CreateInitTask();
    task->Start(this->configUser);
}

void SDKProvisioningConfig::Update()
{
    class ITask * task = this->UpdateManagedItems();
    tList.push_back(task);
    task->Start(&taskUpdateConfig);
}

void SDKProvisioningConfig::ConfigChanged()
{
    this->configUser->ConfigChanged();
}

void SDKProvisioningConfig::WriteConfigItemsComplete(class ITask * task)
{
    tList.remove(task);
    delete task;
    if (stopping) TryClose();
}

void SDKProvisioningConfig::WriteConfigItemsFailed(class ITask * task)
{
    tList.remove(task);
    delete task;
    if (stopping) TryClose();
}