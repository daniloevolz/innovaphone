
var Wecom = Wecom || {};
Wecom.coreconnectorTexts = {
    pt: {
        serverNameSpan: 'Nome do Servidor',
        updateBtn: 'Atualizar',
        serverNameIpt: 'wecom.com.br'
    },
    en: {
    },
    de: {
    }
}
