
var Wecom = Wecom || {};
Wecom.cotacaoTexts = {
    en: {
    },
    de: {
    }
}
