
var Wecom = Wecom || {};
Wecom.cotacaoTexts = {
    pt: {
        salvarClose: "Salvar",
        urlText: "URL do Iframe",
        licText: "Não licenciado, solicite ao seu administrador que licencie o uso da aplicação.",
        licContinue: "Entendo os riscos!"
    },
    en: {
        salvarClose: "Save",
        urlText: "URL of Iframe",
        licText: "Unlicensed, ask your administrator to license the use of the application.",
        licContinue: "I accept the risks!"
    },
    de: {
    }
}
